# MC³-GRAM ablation runner

Built to answer one question with a number: **what does per-client SMOTE
contribute?** That is the row withdrawn from Table 21, and the one gap
Reviewer 2(h) is still open on.

It runs the other eight ablation variants too, so if you regenerate the table
you can regenerate all of it consistently rather than mixing one new row into
eight old ones.

---

## 1. Which dataset to download

### UNSW-NB15 — the one you need

Two different releases circulate under this name and they are **not
interchangeable**. Table 3 of the manuscript describes the first.

**(a) Full capture — `--dataset unsw-full`**

Four CSVs plus a feature-name file:

```
UNSW-NB15_1.csv   UNSW-NB15_2.csv   UNSW-NB15_3.csv   UNSW-NB15_4.csv
NUSW-NB15_features.csv        (the misspelling is the dataset author's)
```

2,540,044 records; Normal 2,218,761, Generic 215,481. Official source:
**research.unsw.edu.au/projects/unsw-nb15-dataset** → "UNSW-NB15 - CSV Files".
Also on Kaggle as `mrwellsdavid/unsw-nb15`.

The four CSVs have **no header row**, which is why the features file is
required. Put all five in one directory.

**(b) Curated ten-class partition — `--dataset unsw-curated`**

```
UNSW_NB15_training-set.csv    UNSW_NB15_testing-set.csv
```

257,673 records. The dataset authors kept every attack class whole and
subsampled Normal to 93,000 and Generic to 58,871 — which is why eight of
Table 3's ten counts match this release exactly and two do not.

It is about ten times smaller, so it is the sensible choice for a first run
or if you are compute-limited. Say so in the paper if you use it.

### CICIDS-2017 — only if you also want Table 22

`MachineLearningCSV.zip` → the `MachineLearningCVE/` folder, eight files:

```
Monday-WorkingHours.pcap_ISCX.csv
Tuesday-WorkingHours.pcap_ISCX.csv
Wednesday-workingHours.pcap_ISCX.csv
Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv
Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv
Friday-WorkingHours-Morning.pcap_ISCX.csv
Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv
Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv
```

2,830,743 records. Source: **unb.ca/cic/datasets/ids-2017.html**, or Kaggle
`cicdataset/cicids2017`. Do **not** use `GeneratedLabelledFlows` — it totals
~2.5M and is a different extraction.

**If you only run one thing, run UNSW-NB15.** That is where the withdrawn row
belongs.

---

## 2. Install

```bash
pip install torch numpy pandas scikit-learn imbalanced-learn
```

A GPU is not required but helps a lot. `--device cpu` forces CPU.

---

## 3. Self-test first

```bash
python selftest.py
```

A minute on synthetic data. It runs every ablation variant end to end on the
CPU and, if a GPU is present, again on the GPU, and checks that every table
it produces satisfies the two identities.

Device mismatches are the characteristic bug in code like this: invisible on
a CPU-only machine, and on a GPU they surface only when the offending line is
first reached -- sometimes after the training is already spent. Run this
before any long job.

## 4. Check the corpus before you train

```bash
python run_ablation.py --dataset unsw-full --root /path/to/UNSW-NB15 --check
```

This trains nothing and takes a couple of minutes. It:

1. compares every class count with Table 3;
2. builds one fold and reports the **class drift of the test partition** —
   this must be near zero. If the test partition comes back balanced,
   resampling has leaked across the split, and every precision-dependent rate
   downstream is inflated. That is the defect recorded in Section 4.13, and
   this check is what keeps it from recurring.

If the counts do not match, stop and fix the download. Nothing downstream
recovers from loading the wrong corpus.

---

## 5. The run that matters

```bash
python run_ablation.py --dataset unsw-full --root /path/to/UNSW-NB15 \
    --variants full no_smote
```

Five folds × two variants = 10 federated runs, each 30 rounds over 10
clients, evaluated at 0/10/20/30% perturbation. `full` and `no_smote` share
the same split, the same Dirichlet draw and the same seeds — the resampling
step is the only difference, which is what makes it a controlled comparison.

Time it first. Add `--subsample 200000 --folds 1 --rounds 3` for a timing
probe, then scale up; the log prints seconds per run.

Everything is appended to `out/results.jsonl` and finished runs are skipped,
so you can stop and restart at will.

To regenerate the whole ablation table:

```bash
python run_ablation.py --dataset unsw-full --root /path/to/UNSW-NB15 \
    --variants full no_smote no_gan no_mask no_trust no_gm \
               fpn_only mlp_only trf_only
```

---

## 6. Get the LaTeX

```bash
python emit_tables.py
```

Writes `out/ablation_rows.tex` (rows for Tables 21/22) and
`out/perclass_rows.tex` (rows for Tables 6–8), and prints a summary.

**It refuses to write anything if a row violates FNR = 1 − Recall or
F1 = 2PR/(P+R).** Those hold by construction for numbers derived from a
confusion matrix, so a failure means the pipeline is wrong, not the rounding
— and they are the first thing a reviewer checks.

---

## 7. What this is, and what it is not

This is an implementation of the equations in Section 3. It is **not** the
code that produced the current Tables 6–22.

That matters for how you use the output:

- **A single new row cannot be pasted into the existing Table 21.** The other
  rows came from different code; mixing them would produce a table whose rows
  are not comparable with each other, which is a worse defect than the
  missing row.
- **Regenerate the whole table, or report this separately.** If you rerun all
  nine variants here, `out/ablation_rows.tex` is internally consistent and can
  replace Table 21 wholesale, with the protocol stated. If you run only the
  SMOTE arm, report it as a separate controlled comparison and say where it
  came from.

If you still have the original codebase, you do not need this. You need one
patch to it: build the folds with the resampling step skipped, change nothing
else, run the same five folds and three budgets, and derive the rates from the
confusion matrix so the identities hold.

---

## 8. Layout

```
config.py     every hyperparameter, transcribed from Table 4
data.py       the three loaders; split -> Dirichlet -> SMOTE -> normalise
model.py      stem, three heads, Jacobian attribution, mask consensus, cGAN
perturb.py    the k% perturbation budget, and rates from the confusion matrix
fed.py        federated loop: drift, trust, trimmed geometric median
selftest.py       every path on synthetic data, CPU and GPU
run_ablation.py   the driver
emit_tables.py    results.jsonl -> LaTeX, with the identity checks
```

Two things in `config.py` are worth knowing about before you run: `rounds`
(30) and `gan_steps` (50) dominate the cost, and `subsample` is `None`, so by
default the full corpus is used.

---

## 9. One thing the paper does not pin down

Section 4.5 says per-client SMOTE balances to "approximately 215,481 samples
per class". That is the Generic count in the full capture, not Normal's
2,218,761 — so either Normal was capped somewhere, or the target was the
largest *attack* class rather than the majority class.

`config.smote_cap` is `None`, which balances each client to its own largest
class. If you know the original behaviour, set it: it changes shard sizes by
an order of magnitude and is the one place this implementation could diverge
from the original by more than seeds.
