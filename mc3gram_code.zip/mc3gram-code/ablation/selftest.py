#!/usr/bin/env python3
"""
Exercise every code path on tiny synthetic data, on CPU and, if one is
present, on the GPU.

Device mismatches are the characteristic failure of this kind of code: they
are invisible on a CPU-only machine and they surface on a GPU only when the
offending line is first reached -- sometimes after the training is already
spent. This runs the whole pipeline in about a minute so that they surface
immediately instead.

    python selftest.py
"""

from __future__ import annotations

import sys

import numpy as np
import pandas as pd
import torch

from config import Config, VERSION, CHANGES
import data as D
from fed import run, ABLATIONS
from perturb import check_identities


def synthetic(n=4000, d=24, n_cls=6, seed=0) -> pd.DataFrame:
    """A small corpus with the real one's defining feature: heavy skew."""
    rng = np.random.default_rng(seed)
    share = np.array([0.55, 0.20, 0.12, 0.08, 0.04, 0.01])
    counts = np.maximum((share * n).astype(int), 30)
    X, y = [], []
    for c, m in enumerate(counts):
        X.append(rng.normal(c * 0.4, 1.0, size=(m, d)))
        y += [f"class{c}"] * m
    df = pd.DataFrame(np.vstack(X).astype(np.float32),
                      columns=[f"f{i}" for i in range(d)])
    df["target"] = y
    return df.sample(frac=1.0, random_state=seed).reset_index(drop=True)


def one(device: str, variants=("full", "no_smote", "no_gan", "no_mask")) -> bool:
    print(f"\n{'=' * 60}\n  device: {device}\n{'=' * 60}")
    cfg = Config(device=device, n_folds=1, rounds=2, local_epochs=1,
                 gan_steps=6, batch_size=256, n_clients=4, smote_cap=400)
    df = synthetic()
    ok = True
    for v in variants:
        folds = D.make_folds(df, cfg, smote=ABLATIONS[v].get("smote", True))
        try:
            model, res = run(folds[0], cfg, ablate=v, log_every=99)
        except Exception as e:
            print(f"  {v:<10} FAILED  {type(e).__name__}: {e}")
            ok = False
            continue
        bad = []
        for b, r in res["budgets"].items():
            bad += check_identities(r)
        m = res["budgets"]["10"]
        status = "ok" if not bad else f"{len(bad)} IDENTITY VIOLATIONS"
        print(f"  {v:<10} acc {m['accuracy']:.4f}  macro-F1 {m['f1']:.4f}   "
              f"{status}")
        ok &= not bad
    return ok


def main() -> int:
    from pathlib import Path
    print(f"mc3gram_ablation {VERSION}  ({CHANGES})")
    print(f"running from {Path(__file__).resolve().parent}")
    print(f"torch {torch.__version__}   cuda available: "
          f"{torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"gpu: {torch.cuda.get_device_name(0)}")

    ok = one("cpu")
    if torch.cuda.is_available():
        ok &= one("cuda")
    else:
        print("\nno GPU here, so the CUDA paths were not exercised.")

    print()
    if ok:
        print("all paths ran and every table satisfied "
              "FNR = 1-Recall and F1 = 2PR/(P+R).")
    else:
        print("SOMETHING FAILED -- see above. Do not start a long run yet.")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
