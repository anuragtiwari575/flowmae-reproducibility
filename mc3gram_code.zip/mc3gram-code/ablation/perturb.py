"""
The perturbation budget of Section 4.1, and metrics computed from the
confusion matrix.

A "perturbation level of k%" has the two-part meaning the manuscript fixes:

    the l-infinity budget is eps = k/100 on min-max normalised features, AND
    adversarially perturbed counterparts are injected for k% of the samples
    of every class.

Both halves matter. Setting eps alone leaves the evaluation set unchanged;
injecting alone leaves attacker strength unscaled. `build_evaluation_set`
does both, per class, so the injected count is proportional within every
class rather than dominated by the majority one.

All rates are derived from a single confusion matrix. That is deliberate:
it makes FNR = 1 - Recall and F1 = 2PR/(P+R) hold by construction, so a
table emitted from these numbers cannot fail the checks a reviewer would
apply to it.
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F


def _dev(module) -> torch.device:
    """The device a module's parameters live on.

    Inputs are built from numpy here, so they start on the CPU; without this
    every evaluation path breaks the moment the model is on a GPU -- and it
    breaks at the END of a long run, after the training is already spent.
    """
    try:
        return next(module.parameters()).device
    except StopIteration:
        return torch.device("cpu")


# ------------------------------------------------- mask-conditioned evasion
def generator_perturbation(gen, model, X, y, eps, mask, n_cls, bs=4096):
    """The manuscript's own perturbation family (Section 4.7).

    The generator proposes a displacement, it is projected into the
    l-infinity ball of radius eps and into [0,1], and off-mask coordinates
    are left alone -- which is what makes these perturbations
    mask-conditioned rather than generic.
    """
    gen.eval()
    dev = _dev(gen)
    mask = mask.to(dev)
    out = []
    with torch.no_grad():
        for i in range(0, len(X), bs):
            xb = torch.from_numpy(X[i:i + bs]).to(dev)
            yb = torch.from_numpy(y[i:i + bs]).to(dev)
            prop = gen(xb.size(0), yb, mask)
            delta = (prop - xb).clamp(-eps, eps) * mask.unsqueeze(0)
            out.append((xb + delta).clamp(0, 1).cpu().numpy())
    return np.concatenate(out).astype(np.float32)


def pgd_perturbation(model, X, y, eps, steps=10, bs=4096):
    """Standard PGD, for the comparison Reviewer 2 asked for."""
    model.eval()
    dev = _dev(model)
    out = []
    alpha = eps / 4
    for i in range(0, len(X), bs):
        x0 = torch.from_numpy(X[i:i + bs]).to(dev)
        yb = torch.from_numpy(y[i:i + bs]).to(dev)
        xb = x0.clone()
        for _ in range(steps):
            xb.requires_grad_(True)
            loss = F.cross_entropy(model(xb), yb)
            g, = torch.autograd.grad(loss, xb)
            xb = xb.detach() + alpha * g.sign()
            xb = torch.min(torch.max(xb, x0 - eps), x0 + eps).clamp(0, 1)
        out.append(xb.detach().cpu().numpy())
    return np.concatenate(out).astype(np.float32)


def build_evaluation_set(X, y, budget, model, gen, mask, n_cls,
                         attack="generator", seed=0):
    """Return the test set at a given perturbation level.

    `budget` is k/100.  For every class, k% of its samples get an adversarial
    counterpart injected alongside the originals; eps is the same k/100.
    """
    if budget <= 0:
        return X, y
    rng = np.random.default_rng(seed)
    pick = []
    for c in np.unique(y):
        idx = np.where(y == c)[0]
        n = int(round(budget * len(idx)))
        if n:
            pick.append(rng.choice(idx, n, replace=False))
    if not pick:
        return X, y
    pick = np.concatenate(pick)

    Xs, ys = X[pick], y[pick]
    if attack == "generator":
        Xa = generator_perturbation(gen, model, Xs, ys, budget, mask, n_cls)
    elif attack == "pgd":
        Xa = pgd_perturbation(model, Xs, ys, budget)
    else:
        raise ValueError(attack)
    return (np.concatenate([X, Xa]).astype(np.float32),
            np.concatenate([y, ys]).astype(np.int64))


# --------------------------------------------------------------- metrics
def confusion(model, X, y, n_cls, bs=8192) -> np.ndarray:
    model.eval()
    dev = _dev(model)
    cm = np.zeros((n_cls, n_cls), dtype=np.int64)
    with torch.no_grad():
        for i in range(0, len(X), bs):
            xb = torch.from_numpy(X[i:i + bs]).to(dev)
            p = model(xb).argmax(1).cpu().numpy()
            np.add.at(cm, (y[i:i + bs], p), 1)
    return cm


def rates_from_confusion(cm: np.ndarray) -> dict:
    """Per-class one-vs-rest rates and their macro averages.

    Everything is derived here and nowhere else, so the identities hold by
    construction rather than by transcription.
    """
    n = cm.sum()
    per = []
    for c in range(cm.shape[0]):
        tp = cm[c, c]
        fn = cm[c].sum() - tp
        fp = cm[:, c].sum() - tp
        tn = n - tp - fn - fp
        rec = tp / (tp + fn) if (tp + fn) else 0.0
        prec = tp / (tp + fp) if (tp + fp) else 0.0
        fpr = fp / (fp + tn) if (fp + tn) else 0.0
        f1 = 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0
        per.append({"support": int(tp + fn),
                    "accuracy": float((tp + tn) / n),
                    "precision": float(prec), "recall": float(rec),
                    "f1": float(f1), "fpr": float(fpr),
                    "fnr": float(1.0 - rec)})
    macro_rec = float(np.mean([p["recall"] for p in per]))
    return {
        "per_class": per,
        "overall_accuracy": float(np.trace(cm) / n),
        "accuracy": float(np.mean([p["accuracy"] for p in per])),
        "precision": float(np.mean([p["precision"] for p in per])),
        "recall": macro_rec,
        "f1": float(np.mean([p["f1"] for p in per])),
        "fpr": float(np.mean([p["fpr"] for p in per])),
        "fnr": float(1.0 - macro_rec),
        "n_eval": int(n),
    }


def check_identities(r: dict, tol: float = 5e-4) -> list[str]:
    """Refuse to believe our own output before it is written anywhere."""
    bad = []
    if abs(r["fnr"] - (1 - r["recall"])) > tol:
        bad.append(f"macro FNR {r['fnr']:.4f} != 1-Recall {1-r['recall']:.4f}")
    for i, p in enumerate(r["per_class"]):
        if abs(p["fnr"] - (1 - p["recall"])) > tol:
            bad.append(f"class {i}: FNR != 1-Recall")
        pr, rc = p["precision"], p["recall"]
        if pr + rc > 0 and abs(p["f1"] - 2 * pr * rc / (pr + rc)) > tol:
            bad.append(f"class {i}: F1 != 2PR/(P+R)")
    return bad
