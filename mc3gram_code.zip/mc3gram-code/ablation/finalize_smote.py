#!/usr/bin/env python3
"""
The last step. Run this when the ablation run has finished.

It does three things that you would otherwise have to do by hand and could
get wrong:

  1. Throws away the timing-probe rows automatically, by two routes, so that
     you never have to edit results.jsonl by hand -- which matters, because
     the run appends to it while it works.

     If a record's key carries a protocol fingerprint (v5 and later), the
     protocol used by most full-model folds wins and the rest are dropped.

     If it does not (v4 and earlier wrote bare keys), the runtime decides:
     a three-round probe takes a small fraction of the time a thirty-round
     fold takes, so within each variant any fold far below the median is a
     probe. Both routes report what they dropped rather than dropping it
     silently.

  2. Reports the CLEAN (0% budget) numbers only. The perturbation budgets in
     this reimplementation move samples toward their class prototype rather
     than away from it, so they do not measure what the manuscript's budget
     columns measure and are not reported.

  3. Prints the LaTeX block to paste into the manuscript, and the one-line
     sentence for the response letter.

    python finalize_smote.py
"""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

import numpy as np

OUT = Path(__file__).parent / "out"
RESULTS = OUT / "results.jsonl"

FIELDS = ("accuracy", "precision", "recall", "f1")

# The manuscript spells the fold count out, so the macro carries a word.
WORD = {1: "one", 2: "two", 3: "three", 4: "four", 5: "five"}


def main() -> int:
    if not RESULTS.exists():
        raise SystemExit(f"{RESULTS} not found -- run run_ablation.py first")
    rows = [json.loads(l) for l in RESULTS.read_text().splitlines() if l.strip()]

    # --- pick the protocol ------------------------------------------------
    by_proto = defaultdict(list)
    for r in rows:
        p = r["key"].split("|")
        by_proto[p[3] if len(p) > 3 else "unversioned"].append(r)

    def n_full(recs):
        return sum(1 for r in recs if r["key"].split("|")[1] == "full")

    proto = max(by_proto, key=lambda t: (n_full(by_proto[t]), len(by_proto[t])))
    keep = by_proto[proto]
    print(f"protocol kept: {proto}   ({len(keep)} runs)")
    for t, recs in sorted(by_proto.items()):
        if t != proto:
            print(f"  dropped {t:<28} {len(recs)} run(s)  "
                  f"(different protocol -- not averaged in)")

    # --- second route: runtime, for records whose keys carry no protocol ---
    # A thirty-round fold costs many times what a three-round probe costs, and
    # the ratio is nowhere near the spread between folds of one variant, so a
    # fold far below its variant's median is a probe and nothing else.
    PROBE_RATIO = 0.4
    by_var = defaultdict(list)
    for r in keep:
        by_var[r["key"].split("|")[1]].append(r)

    survivors, probes = [], []
    for var, recs in by_var.items():
        secs = [r["meta"]["secs"] for r in recs]
        if len(recs) < 3:
            survivors += recs          # too few to call an outlier
            continue
        floor = PROBE_RATIO * float(np.median(secs))
        for r in recs:
            (probes if r["meta"]["secs"] < floor else survivors).append(r)

    if probes:
        print("\ndropped as timing probes (runtime far below the variant's "
              "median):")
        for r in sorted(probes, key=lambda r: r["key"]):
            print(f"  {r['key']:<28} {r['meta']['secs']:>7.0f}s")
        print("  results.jsonl itself is untouched.")
    keep = survivors

    # A variant whose probe fold was dropped while the other variant's was
    # kept would make the two arms non-comparable, which is the one thing
    # this comparison cannot survive.
    folds = {v: {r["key"].split("|")[2] for r in keep
                 if r["key"].split("|")[1] == v}
             for v in ("full", "no_smote") if any(
                 r["key"].split("|")[1] == v for r in keep)}
    if len(folds) == 2:
        common = folds["full"] & folds["no_smote"]
        extra = (folds["full"] | folds["no_smote"]) - common
        if extra:
            print(f"\nfolds present for one arm but not the other: "
                  f"{', '.join(sorted(extra))}")
            print("  dropping them -- the arms must be paired on the same "
                  "folds or the comparison is not controlled.")
            keep = [r for r in keep if r["key"].split("|")[2] in common]

    # --- clean numbers ----------------------------------------------------
    g = defaultdict(list)
    for r in keep:
        var = r["key"].split("|")[1]
        if "0" in r["budgets"]:
            g[var].append(r["budgets"]["0"])

    if "full" not in g or "no_smote" not in g:
        raise SystemExit("need both 'full' and 'no_smote' runs at this protocol")

    nf, nn = len(g["full"]), len(g["no_smote"])
    print(f"\nclean (0% budget) folds:  full {nf}   no_smote {nn}")
    if nf != nn:
        print("  the arms are not paired -- do not report this yet")
    elif nf < 5:
        print(f"  {nf} paired folds rather than five. That is a sound "
              "comparison, provided the paper says so; the manuscript takes "
              "the count from this script.")

    stat = {}
    for var in ("full", "no_smote"):
        stat[var] = {f: (float(np.mean([r[f] for r in g[var]])),
                         float(np.std([r[f] for r in g[var]])))
                     for f in FIELDS}

    f_hi, s_hi = stat["full"]["f1"]
    f_lo, s_lo = stat["no_smote"]["f1"]
    gap = f_hi - f_lo
    pooled = float(np.sqrt((s_hi ** 2 + s_lo ** 2) / 2))

    print(f"\n  full        macro-F1 {f_hi:.4f} +- {s_hi:.4f}")
    print(f"  no_smote    macro-F1 {f_lo:.4f} +- {s_lo:.4f}")
    print(f"  gap         {gap:+.4f}   (pooled s.d. {pooled:.4f}"
          + (f", {gap/pooled:.1f} sd)" if pooled > 0 else ")"))

    # --- LaTeX ------------------------------------------------------------
    def cell(var, f):
        m, s = stat[var][f]
        return f"{m:.4f}\\,$\\pm$\\,{s:.3f}"

    lines = [
        "% ---- paste this block over the four \\newcommand lines in main.tex",
        f"\\newcommand{{\\smotefolds}}{{{WORD.get(min(nf, nn), min(nf, nn))}}}",
        f"\\newcommand{{\\smotefull}}{{{f_hi:.4f}}}",
        f"\\newcommand{{\\smotenone}}{{{f_lo:.4f}}}",
        f"\\newcommand{{\\smotegap}}{{{gap:.4f}}}",
        "",
        "% ---- and this block over the two data rows of Table~\\ref{tab:smote_ablation}",
        "MC\\textsuperscript{3}-GRAM (full) & "
        + " & ".join(cell("full", f) for f in FIELDS) + " \\\\ \\hline",
        "\\quad w/o per-client SMOTE & "
        + " & ".join(cell("no_smote", f) for f in FIELDS) + " \\\\ \\hline",
    ]
    block = "\n".join(lines)
    (OUT / "smote_final.tex").write_text(block + "\n")
    print("\n" + block)
    print(f"\nwrote {OUT / 'smote_final.tex'}")
    print("\nSend that file, or just the numbers above, to have them placed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
