#!/usr/bin/env python3
"""
Scan a folder tree and report which corpus files are present.

Run this first if the download landed in several places. It reads nothing
into memory beyond a header, so it takes seconds:

    python find_data.py "C:\\Users\\You\\Downloads"

It prints the folder to pass as --root for each corpus it can assemble.
"""

from __future__ import annotations

import sys
from pathlib import Path

WANT = {
    "unsw-full": ["UNSW-NB15_1.csv", "UNSW-NB15_2.csv", "UNSW-NB15_3.csv",
                  "UNSW-NB15_4.csv"],
    "unsw-full (optional)": ["NUSW-NB15_features.csv"],
    "unsw-curated": ["UNSW_NB15_training-set.csv", "UNSW_NB15_testing-set.csv"],
    "cicids": ["Monday-WorkingHours.pcap_ISCX.csv",
               "Tuesday-WorkingHours.pcap_ISCX.csv",
               "Wednesday-workingHours.pcap_ISCX.csv",
               "Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv",
               "Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv",
               "Friday-WorkingHours-Morning.pcap_ISCX.csv",
               "Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv",
               "Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv"],
}


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    root = Path(sys.argv[1]).expanduser()
    if not root.exists():
        print(f"{root} does not exist")
        return 1

    print(f"scanning {root} ...\n")
    index: dict[str, list[Path]] = {}
    for p in root.rglob("*.csv"):
        index.setdefault(p.name, []).append(p)

    common: list[Path] = []
    for corpus, files in WANT.items():
        print(f"  {corpus}")
        found_dirs = []
        for f in files:
            hits = index.get(f, [])
            if hits:
                print(f"     found    {f}")
                print(f"              {hits[0].parent}")
                found_dirs.append(hits[0].parent)
            else:
                print(f"     MISSING  {f}")
        if found_dirs and len(found_dirs) == len(files):
            if len(set(found_dirs)) == 1:
                print(f"     -> --root \"{found_dirs[0]}\"")
            else:
                anc = found_dirs[0]
                while not all(str(d).startswith(str(anc)) for d in found_dirs):
                    if anc.parent == anc:
                        break
                    anc = anc.parent
                print(f"     files are spread across folders; their common "
                      f"parent works:")
                print(f"     -> --root \"{anc}\"")
                common.append(anc)
        print()

    print("The loader searches --root recursively, so a common parent folder")
    print("is enough -- the files do not have to be moved together.")
    if "NUSW-NB15_features.csv" not in index:
        print("\nNUSW-NB15_features.csv was not found. That is fine: the four")
        print("raw CSVs have no header row, and the canonical 49-column order")
        print("is built into data.py as a fallback.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
