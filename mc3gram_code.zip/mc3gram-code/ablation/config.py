"""
Every hyperparameter in one place, transcribed from Table 4 of the manuscript.

Nothing here is tuned. If a value disagrees with the paper, change it here and
nowhere else, so that a reader can check the whole configuration against
Table 4 in one screen.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# Bumped whenever the code changes.  Printed by every entry point, because
# extracting a zip beside an older copy is easy to do and impossible to see
# from the output otherwise.
VERSION = "2026-09-15.6"
CHANGES = "finalize_smote.py: auto-drops probe rows, emits the final block"


@dataclass
class Config:
    # ---- architecture (Table 4) -------------------------------------------
    n_heads: int = 3                 # FPN, Residual-MLP, Transformer
    d_latent: int = 128              # stem width
    tau_mask: float = 0.5            # logit-space mask-consensus temperature
    keep_frac: float = 0.6           # fraction of features the consensus keeps

    # ---- generator / critic (Table 4) -------------------------------------
    noise_dim: int = 64              # "Latent dim", generator input size
    xi: float = 0.05                 # Wasserstein plausibility bound
    lam_recon: float = 0.3           # mask-aligned reconstruction weight
    beta: float = 0.4                # real/fake vs consistency weight
    gamma: float = 0.5               # Wasserstein-penalty weight
    gen_lr: float = 0.001
    disc_lr: float = 0.01

    # ---- federated layer (Table 4) ----------------------------------------
    lam1: float = 0.5                # parameter-drift weight
    lam2: float = 0.3                # mask-drift weight
    lam3: float = 0.2                # reported-validation weight
    mu_personal: float = 0.2         # per-client personalisation
    trim: float = 0.2                # trimmed geometric median

    # ---- protocol (Section 4.1) -------------------------------------------
    n_clients: int = 10
    alpha: float = 0.5               # Dirichlet label-skew concentration
    n_folds: int = 5
    seeds: tuple = (0, 1, 2, 3, 4)
    split: tuple = (0.7, 0.1, 0.2)   # train / val / test

    # ---- training ---------------------------------------------------------
    rounds: int = 30
    local_epochs: int = 2
    batch_size: int = 512
    clf_lr: float = 1e-3
    gan_steps: int = 50              # generator/critic steps per client round

    # ---- evasion budgets (Section 4.1) ------------------------------------
    # "perturbation level of k%" = eps k/100 on min-max normalised features
    # AND adversarial counterparts injected for k% of every class's samples.
    budgets: tuple = (0.10, 0.20, 0.30)

    # ---- practical --------------------------------------------------------
    device: str = "cuda"             # falls back to cpu automatically
    subsample: int | None = None     # None = full corpus; set an int to shrink
    smote_cap: int | None = None     # None = balance to the client's largest
    num_workers: int = 0

    def describe(self) -> str:
        return (f"{self.n_clients} clients, Dirichlet({self.alpha}), "
                f"{self.n_folds} folds, {self.rounds} rounds x "
                f"{self.local_epochs} local epochs, batch {self.batch_size}")


DEFAULT = Config()
