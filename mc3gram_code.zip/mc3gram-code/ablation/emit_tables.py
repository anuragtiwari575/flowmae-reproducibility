#!/usr/bin/env python3
"""
Turn out/results.jsonl into the LaTeX rows the manuscript needs.

Two outputs:

  out/ablation_rows.tex   rows for Tables 21/22, one per variant per budget
  out/perclass_rows.tex   per-class rows for Tables 6-8, full model

Nothing is written if any row fails FNR = 1 - Recall or F1 = 2PR/(P+R).
Those identities hold by construction for numbers derived from a confusion
matrix, so a failure here means something has gone wrong in the pipeline, not
in the rounding -- and a table that fails them is exactly what a reviewer
checks first.
"""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

import numpy as np

OUT = Path(__file__).parent / "out"
RESULTS = OUT / "results.jsonl"

LABEL = {
    "full": "MC\\textsuperscript{3}-GRAM (full)",
    "no_smote": "\\quad w/o per-client SMOTE",
    "no_gan": "\\quad w/o generative augmentation",
    "no_mask": "\\quad w/o mask consensus",
    "no_trust": "\\quad w/o trust weighting",
    "no_gm": "\\quad w/o trimmed geometric median",
    "fpn_only": "\\quad FPN head only",
    "mlp_only": "\\quad Residual-MLP head only",
    "trf_only": "\\quad Transformer head only",
}
ORDER = list(LABEL)
TOL = 5e-4


def load():
    if not RESULTS.exists():
        raise SystemExit(f"{RESULTS} not found -- run run_ablation.py first")
    return [json.loads(l) for l in RESULTS.read_text().splitlines() if l.strip()]


def protocols(rows) -> dict:
    """Group runs by the protocol fingerprint in their key, if present."""
    seen = {}
    for rec in rows:
        parts = rec["key"].split("|")
        tag = parts[3] if len(parts) > 3 else "unversioned"
        seen.setdefault(tag, []).append(rec["key"])
    return seen


def verify(rows) -> list[str]:
    bad = []
    for rec in rows:
        for b, r in rec["budgets"].items():
            if abs(r["fnr"] - (1 - r["recall"])) > TOL:
                bad.append(f"{rec['key']} @{b}%: macro FNR != 1-Recall")
            for i, p in enumerate(r["per_class"]):
                if abs(p["fnr"] - (1 - p["recall"])) > TOL:
                    bad.append(f"{rec['key']} @{b}% class {i}: FNR != 1-Recall")
                pr, rc = p["precision"], p["recall"]
                if pr + rc > 0 and abs(p["f1"] - 2*pr*rc/(pr+rc)) > TOL:
                    bad.append(f"{rec['key']} @{b}% class {i}: F1 != 2PR/(P+R)")
    return bad


def ms(v, s):
    return f"{v:.4f}\\,$\\pm$\\,{s:.3f}"


def ablation_rows(rows):
    g = defaultdict(list)
    for rec in rows:
        var = rec["key"].split("|")[1]
        for b, r in rec["budgets"].items():
            if b == "0":
                continue
            g[(var, int(b))].append(r)
    budgets = sorted({b for _, b in g})
    L = []
    for b in budgets:
        n = max(len(v) for k, v in g.items() if k[1] == b)
        L += [f"% ---- {b}\\% perturbation budget, mean +- s.d. over {n} folds",
              "\\hline"]
        for var in ORDER:
            rs = g.get((var, b))
            if not rs:
                continue
            cells = []
            for f in ("accuracy", "precision", "recall", "f1", "fpr", "fnr"):
                vals = [r[f] for r in rs]
                cells.append(ms(float(np.mean(vals)), float(np.std(vals))))
            L.append(f"{LABEL[var]} & " + " & ".join(cells) + " \\\\ \\hline")
        L.append("")
    return "\n".join(L)


def perclass_rows(rows):
    g = defaultdict(lambda: defaultdict(list))
    classes = None
    for rec in rows:
        if rec["key"].split("|")[1] != "full":
            continue
        classes = rec["meta"]["classes"]
        for b, r in rec["budgets"].items():
            if b == "0":
                continue
            for i, p in enumerate(r["per_class"]):
                g[int(b)][i].append(p)
    if classes is None:
        return ""
    L = []
    for b in sorted(g):
        L += [f"% ---- Table 6-8 style, {b}\\% budget, full model", "\\hline"]
        macro = defaultdict(list)
        for i, name in enumerate(classes):
            rs = g[b][i]
            cells = []
            for f in ("accuracy", "precision", "recall", "f1", "fpr", "fnr"):
                v = float(np.mean([p[f] for p in rs]))
                macro[f].append(v)
                cells.append(f"{v:.4f}")
            L.append(f"{name} & " + " & ".join(cells) + " \\\\ \\hline")
        avg = " & ".join(f"\\textbf{{{np.mean(macro[f]):.4f}}}" for f in
                         ("accuracy", "precision", "recall", "f1", "fpr", "fnr"))
        L.append(f"\\textbf{{Avg.}} & {avg} \\\\ \\hline")
        L.append("")
    return "\n".join(L)


def summary(rows):
    print(f"{'variant':<34}{'budget':>8}{'acc':>9}{'macro-F1':>10}{'folds':>7}")
    g = defaultdict(list)
    for rec in rows:
        var = rec["key"].split("|")[1]
        for b, r in rec["budgets"].items():
            g[(var, b)].append(r)
    for (var, b) in sorted(g, key=lambda k: (ORDER.index(k[0])
                                             if k[0] in ORDER else 99, k[1])):
        rs = g[(var, b)]
        print(f"{LABEL.get(var, var)[:33]:<34}{b + '%':>8}"
              f"{np.mean([r['accuracy'] for r in rs]):>9.4f}"
              f"{np.mean([r['f1'] for r in rs]):>10.4f}{len(rs):>7}")


def main():
    rows = load()
    print(f"loaded {len(rows)} runs\n")

    # Averaging runs from different protocols into one row would be silent and
    # wrong, so say something rather than let it through.
    ps = protocols(rows)
    if len(ps) > 1:
        print("WARNING: these runs came from more than one protocol:")
        for tag, keys in sorted(ps.items()):
            print(f"   {tag:<28} {len(keys)} run(s)")
        print("   Delete the rows you do not want from out/results.jsonl and")
        print("   re-run those folds before trusting any averaged row.\n")
    bad = verify(rows)
    if bad:
        print(f"IDENTITY VIOLATIONS ({len(bad)}) -- nothing written:")
        for b in bad[:15]:
            print("   ", b)
        raise SystemExit(1)
    print("identity check: 0 violations\n")
    summary(rows)
    (OUT / "ablation_rows.tex").write_text(ablation_rows(rows))
    (OUT / "perclass_rows.tex").write_text(perclass_rows(rows))
    print(f"\nwrote {OUT/'ablation_rows.tex'}")
    print(f"wrote {OUT/'perclass_rows.tex'}")
    print("\nPaste the w/o-SMOTE line into Table 21 beside the full-model row.")


if __name__ == "__main__":
    main()
