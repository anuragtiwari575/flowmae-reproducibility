#!/usr/bin/env python3
"""
Run the ablation grid and write one JSON record per (variant, fold).

The run that matters most is the SMOTE arm, because it is the one row of
Table 21 that was withdrawn:

    python run_ablation.py --dataset unsw-full --root /path/to/UNSW-NB15 \
        --variants full no_smote

Everything is checkpointed to out/results.jsonl and already-finished runs are
skipped, so this can be stopped and restarted freely.

Start with --check, which loads the corpus, compares the counts with Table 3,
builds one fold and verifies that the test partition has not been rebalanced.
It trains nothing and takes a couple of minutes. If it fails, no amount of
care downstream will fix what it found.
"""

from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

import numpy as np
import torch

import data as D
from config import Config, VERSION, CHANGES
from fed import run, ABLATIONS
from perturb import check_identities

OUT = Path(__file__).parent / "out"
OUT.mkdir(exist_ok=True)
RESULTS = OUT / "results.jsonl"


def protocol_tag(cfg) -> str:
    """A short fingerprint of everything that changes what a run means.

    The resume key has to carry this. Without it a three-round timing probe
    and a thirty-round real run share a key, the real run silently skips the
    fold the probe already wrote, and the two protocols end up averaged
    together in one table.
    """
    return (f"r{cfg.rounds}e{cfg.local_epochs}c{cfg.n_clients}"
            f"a{cfg.alpha}k{cfg.smote_cap or 0}s{cfg.subsample or 0}")


def done() -> set:
    if not RESULTS.exists():
        return set()
    return {json.loads(l)["key"] for l in RESULTS.read_text().splitlines()
            if l.strip()}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True,
                    choices=["unsw-full", "unsw-curated", "cicids"])
    ap.add_argument("--root", required=True, help="directory holding the CSVs")
    ap.add_argument("--variants", nargs="+", default=["full", "no_smote"],
                    choices=sorted(ABLATIONS))
    ap.add_argument("--folds", type=int, default=None,
                    help="override the number of folds (default 5)")
    ap.add_argument("--rounds", type=int, default=None)
    ap.add_argument("--subsample", type=int, default=None,
                    help="shrink the corpus; results are then not full-corpus")
    ap.add_argument("--smote-cap", type=int, default=None,
                    help="cap the per-class SMOTE target. Without it a client "
                         "holding much of Normal balances every class up to "
                         "millions of rows; 50000 is a sane starting point.")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--check", action="store_true",
                    help="verify corpus and split, train nothing")
    args = ap.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s",
                        datefmt="%H:%M:%S")
    print(f"mc3gram_ablation {VERSION}  ({CHANGES})")
    print(f"running from {Path(__file__).resolve().parent}\n")
    cfg = Config(device=args.device)
    if args.folds:
        cfg.n_folds = args.folds
    if args.rounds:
        cfg.rounds = args.rounds
    if args.subsample:
        cfg.subsample = args.subsample
    if args.smote_cap:
        cfg.smote_cap = args.smote_cap

    df = D.load(args.dataset, args.root)
    counts_ok = D.check_counts(args.dataset, df)

    if args.check:
        print("\nbuilding one fold to verify the split ordering ...")
        # One fold is enough to verify the ordering, and the test partition
        # is still the 20% of Section 4.1 -- the splitter's geometry does not
        # depend on how many folds are actually built.
        f = D.make_folds(df, Config(**{**cfg.__dict__, "n_folds": 1}),
                         smote=True)[0]
        D.verify_split(f, df)
        sizes = {c: len(y) for c, (_, y) in f.clients.items()}
        print(f"  client shard sizes after SMOTE: {min(sizes.values()):,} "
              f"- {max(sizes.values()):,}")
        print("\n" + ("all checks passed" if counts_ok else
                      "COUNTS DO NOT MATCH -- fix the download first"))
        return 0 if counts_ok else 1

    print(f"\nprotocol: {cfg.describe()}")
    print(f"budgets:  {', '.join(f'{int(b*100)}%' for b in cfg.budgets)}\n")

    have = done()
    for variant in args.variants:
        # the SMOTE arm needs folds built without resampling; everything else
        # about them -- split, Dirichlet draw, seeds -- is identical
        use_smote = ABLATIONS[variant].get("smote", True)
        folds = D.make_folds(df, cfg, smote=use_smote)
        for f in folds:
            key = f"{args.dataset}|{variant}|f{f.fold}|{protocol_tag(cfg)}"
            if key in have:
                logging.info("skip %s (already done)", key)
                continue
            logging.info("=== %s ===", key)
            _, res = run(f, cfg, ablate=variant)

            bad = []
            for b, r in res["budgets"].items():
                bad += [f"budget {b}: {m}" for m in check_identities(r)]
            if bad:
                logging.error("IDENTITY VIOLATIONS -- not recorded:")
                for b in bad[:10]:
                    logging.error("   %s", b)
                continue

            with RESULTS.open("a") as fh:
                fh.write(json.dumps({"key": key, "dataset": args.dataset,
                                     **res}) + "\n")
            m = res["budgets"][str(int(cfg.budgets[0] * 100))]
            logging.info("recorded %s   acc %.4f  macro-F1 %.4f  (%.0fs)",
                         key, m["accuracy"], m["f1"], res["meta"]["secs"])

    print(f"\ndone. {RESULTS}")
    print("next:  python emit_tables.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
