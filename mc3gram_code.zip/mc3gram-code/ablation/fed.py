"""
The federated training loop.

    Eqs 26-27   global mask aggregation
    Eqs 28-33   conditional generator, dual-head critic, Wasserstein hinge
    Eqs 36-38   drift score, trust weights
    Eq  39      trimmed geometric median (Weiszfeld)

`ablate` is the only thing an ablation changes. Every other input -- the
folds, the Dirichlet draw, the seeds, the schedule -- is held fixed, which is
what makes a row of the ablation table a controlled comparison rather than
two separate experiments.
"""

from __future__ import annotations

import copy
import logging
import os
import time

import numpy as np
import torch
import torch.nn.functional as F

from model import MC3GRAM, Generator, Critic, critic_clip, mask_consensus
from perturb import confusion, rates_from_confusion, build_evaluation_set

log = logging.getLogger(__name__)
torch.set_num_threads(int(os.environ.get("MC3_THREADS", "4")))


def device_of(cfg):
    return torch.device(cfg.device if (cfg.device == "cuda"
                                       and torch.cuda.is_available()) else "cpu")


# ------------------------------------------------------------ local training
def local_train(model, X, y, cfg, gen=None, mask=None, dev="cpu"):
    model.train()
    opt = torch.optim.Adam(model.parameters(), lr=cfg.clf_lr)
    Xt = torch.from_numpy(X)
    yt = torch.from_numpy(y)
    n = len(X)
    for _ in range(cfg.local_epochs):
        perm = torch.randperm(n)
        for i in range(0, n, cfg.batch_size):
            idx = perm[i:i + cfg.batch_size]
            xb, yb = Xt[idx].to(dev), yt[idx].to(dev)
            if xb.size(0) < 2:
                continue
            if gen is not None:
                k = max(1, int(0.15 * xb.size(0)))
                cnt = torch.bincount(yb, minlength=model.n_cls).float()
                cnt[cnt == 0] = float("inf")
                rare = torch.topk(-cnt, min(3, model.n_cls)).indices
                ys = rare[torch.randint(0, len(rare), (k,), device=dev)]
                gen.eval()
                with torch.no_grad():
                    xs = gen(k, ys, mask)
                xb = torch.cat([xb, xs], 0)
                yb = torch.cat([yb, ys], 0)
            opt.zero_grad()
            F.cross_entropy(model(xb), yb).backward()
            opt.step()
    return model


def train_gan(gen, crt, X, y, mask, cfg, dev="cpu", w1_log=None):
    """Wasserstein-hinge GAN with the plausibility penalty of Eq. 33.

    The xi term is a soft penalty, not a constraint: it pushes a batch whose
    critic-estimated W1 exceeds xi back toward the threshold without
    preventing the excursion. `w1_log` records every batch so the violation
    rate can be reported rather than assumed.
    """
    og = torch.optim.Adam(gen.parameters(), lr=cfg.gen_lr, betas=(0.5, 0.9))
    oc = torch.optim.Adam(crt.parameters(), lr=cfg.disc_lr, betas=(0.5, 0.9))
    Xt, yt = torch.from_numpy(X), torch.from_numpy(y)
    n = len(X)
    bs = min(cfg.batch_size, max(8, n // 2))
    for s in range(cfg.gan_steps):
        idx = torch.randint(0, n, (bs,))
        xr, yr = Xt[idx].to(dev), yt[idx].to(dev)
        gen.eval(); crt.train()
        with torch.no_grad():
            xf = gen(bs, yr, mask)
        wr, cr = crt(xr)
        wf, _ = crt(xf)
        d_loss = (F.relu(1 - wr).mean() + F.relu(1 + wf).mean()
                  + cfg.beta * F.cross_entropy(cr, yr))
        oc.zero_grad(); d_loss.backward(); oc.step()
        critic_clip(crt)
        if s % 2 == 0:
            gen.train(); crt.eval()
            xf = gen(bs, yr, mask)
            wf, cf = crt(xf)
            with torch.no_grad():
                wr_g, _ = crt(xr)
            w1 = wr_g.mean() - wf.mean()
            recon = ((xf - xr) ** 2 * mask.unsqueeze(0)).mean()
            g_loss = (-wf.mean() + cfg.beta * F.cross_entropy(cf, yr)
                      + cfg.lam_recon * recon
                      + cfg.gamma * torch.clamp(w1 - cfg.xi, min=0))
            og.zero_grad(); g_loss.backward(); og.step()
            if w1_log is not None:
                w1_log.append(float(w1.detach()))
    return gen, crt


# --------------------------------------------------------------- aggregation
def flatten(sd):
    return torch.cat([v.flatten().float() for v in sd.values()])


def unflatten(vec, ref):
    out, i = {}, 0
    for k, v in ref.items():
        n = v.numel()
        out[k] = vec[i:i + n].view_as(v).to(v.dtype)
        i += n
    return out


def geometric_median(P, w, iters=15, eps=1e-8):
    m = (P * w[:, None]).sum(0) / w.sum()
    for _ in range(iters):
        d = torch.norm(P - m, dim=1).clamp_min(eps)
        ww = w / d
        nm = (P * ww[:, None]).sum(0) / ww.sum()
        if torch.norm(nm - m) < 1e-7:
            break
        m = nm
    return m


def aggregate(gsd, sds, val_acc, mask_drift, cfg, use_trust=True, use_gm=True):
    g = flatten(gsd)
    P = torch.stack([flatten(s) for s in sds])
    pdrift = torch.norm(P - g[None, :], dim=1)                      # Eq. 36
    dev = pdrift.device
    pd_n = pdrift / (pdrift.median() + 1e-8)
    md_n = torch.tensor(mask_drift, dtype=torch.float32, device=dev)
    va = torch.tensor(val_acc, dtype=torch.float32, device=dev)

    if use_trust:
        # Eq. 36: drift combines parameter drift, mask drift and the reported
        # validation score, with only the last of the three self-reported.
        drift = cfg.lam1 * pd_n + cfg.lam2 * md_n - cfg.lam3 * va
        w = torch.softmax(-drift, 0).clamp_min(1e-8)                # Eq. 37
    else:
        w = torch.ones(len(P), device=dev)
    w = w / w.sum()

    w_full = torch.zeros(len(P), device=dev)
    if cfg.trim > 0 and len(P) >= 5:
        keep = int(round((1 - cfg.trim) * len(P)))
        order = torch.argsort(pdrift)[:keep]
        Pk, wk = P[order], w[order] / w[order].sum()
        w_full[order] = wk
    else:
        order = torch.arange(len(P), device=dev)
        Pk, wk = P, w
        w_full = w.clone()

    m = geometric_median(Pk, wk) if use_gm else (Pk * wk[:, None]).sum(0)
    return unflatten(m, gsd), pdrift, w_full


# ------------------------------------------------------------------- the run
ABLATIONS = {
    "full":        {},
    "no_smote":    {"smote": False},
    "no_gan":      {"gan": False},
    "no_mask":     {"mask": False},
    "no_trust":    {"trust": False},
    "no_gm":       {"gm": False},
    "fpn_only":    {"heads": ("fpn",)},
    "mlp_only":    {"heads": ("mlp",)},
    "trf_only":    {"heads": ("trf",)},
}


def run(fold, cfg, ablate: str = "full", log_every: int = 5):
    """One federated training run, then evaluation at every budget."""
    opts = ABLATIONS[ablate]
    dev = device_of(cfg)
    d_in = fold.X_val.shape[1]
    n_cls = len(fold.classes)
    heads = opts.get("heads", ("fpn", "mlp", "trf"))
    use_gan = opts.get("gan", True)
    use_mask = opts.get("mask", True)

    torch.manual_seed(fold.seed)
    model = MC3GRAM(d_in, n_cls, d=cfg.d_latent, heads=heads).to(dev)
    model.n_cls = n_cls
    gen = Generator(d_in, n_cls, d_noise=cfg.noise_dim).to(dev) if use_gan else None
    crt = Critic(d_in, n_cls).to(dev) if use_gan else None

    cids = sorted(fold.clients)
    prev_mask = model.feature_mask.clone()
    w1_log, t0 = [], time.time()

    for rnd in range(cfg.rounds):
        gsd = copy.deepcopy(model.state_dict())
        sds, accs, mdrift = [], [], []
        for cid in cids:
            Xc, yc = fold.clients[cid]
            lm = MC3GRAM(d_in, n_cls, d=cfg.d_latent, heads=heads).to(dev)
            lm.n_cls = n_cls
            lm.load_state_dict(gsd)
            if use_gan:
                train_gan(gen, crt, Xc, yc, model.feature_mask, cfg, dev, w1_log)
            local_train(lm, Xc, yc, cfg, gen=gen,
                        mask=model.feature_mask, dev=dev)
            sub = np.random.default_rng(fold.seed + rnd).choice(
                len(fold.X_val), min(8192, len(fold.X_val)), replace=False)
            cm = confusion(lm, fold.X_val[sub], fold.y_val[sub], n_cls)
            accs.append(rates_from_confusion(cm)["overall_accuracy"])
            lmask = lm.feature_mask
            mdrift.append(float((lmask - model.feature_mask).abs().mean()))
            sds.append(copy.deepcopy(lm.state_dict()))

        new_sd, _, _ = aggregate(gsd, sds, accs, mdrift, cfg,
                                 use_trust=opts.get("trust", True),
                                 use_gm=opts.get("gm", True))
        model.load_state_dict(new_sd)

        if use_mask:
            sub = np.random.default_rng(rnd).choice(
                len(fold.X_val), min(4096, len(fold.X_val)), replace=False)
            attr = model.attribution(torch.from_numpy(fold.X_val[sub]).to(dev))
            m, _ = mask_consensus(attr, cfg.keep_frac)
            model.feature_mask.copy_(m.to(dev))
        if (rnd + 1) % log_every == 0:
            cm = confusion(model, fold.X_val, fold.y_val, n_cls)
            log.info("    round %2d/%d  val acc %.4f", rnd + 1, cfg.rounds,
                     rates_from_confusion(cm)["overall_accuracy"])

    # ---- evaluation at each perturbation budget --------------------------
    results = {}
    for k in (0.0,) + tuple(cfg.budgets):
        Xe, ye = build_evaluation_set(
            fold.X_test, fold.y_test, k, model, gen, model.feature_mask,
            n_cls, attack="generator" if use_gan else "pgd", seed=fold.seed)
        cm = confusion(model, Xe, ye, n_cls)
        r = rates_from_confusion(cm)
        r["confusion"] = cm.tolist()
        r["budget"] = k
        results[f"{int(k*100)}"] = r

    meta = {"ablation": ablate, "fold": fold.fold, "seed": fold.seed,
            "classes": fold.classes, "secs": round(time.time() - t0, 1),
            "mask_kept": int(model.feature_mask.sum().item()),
            "n_features": d_in, "n_clients": len(cids)}
    if w1_log:
        a = np.asarray(w1_log)
        meta.update(w1_mean=float(a.mean()), w1_max=float(a.max()),
                    w1_violation_rate=float((a > cfg.xi).mean()),
                    w1_batches=int(a.size), xi=cfg.xi)
    return model, {"meta": meta, "budgets": results}
