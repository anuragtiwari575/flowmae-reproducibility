"""
Corpus loading and the split / partition / resample pipeline.

Three corpora are supported, and which one you load matters:

  unsw-full     UNSW-NB15_1..4.csv + NUSW-NB15_features.csv
                2,540,044 records.  This is what Table 3 of the manuscript
                describes (Normal 2,218,761; Generic 215,481).
  unsw-curated  UNSW_NB15_training-set.csv + UNSW_NB15_testing-set.csv
                257,673 records.  Every attack class is carried over whole
                from the full capture -- so eight of Table 3's ten counts
                match exactly -- but Normal and Generic were subsampled by
                the dataset authors to 93,000 and 58,871.
  cicids        the eight MachineLearningCVE CSVs, 2,830,743 records.

The ordering below is the one Section 4.1 fixes, and it is the single most
consequential methodological decision in the pipeline:

    stratified 70/10/20 split
            |                    <- validation and test frozen here
    Dirichlet(alpha) over the TRAINING split only
            |
    per-client SMOTE, on that client's own shard
            |
    min-max normalisation, fitted on training rows only

SMOTE and the normalisation statistics never touch validation or test data.
Resampling before the split is what puts synthetic minority points into the
test partition and inflates every rate that depends on precision; `verify()`
below checks that it has not happened.
"""

from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold, train_test_split

log = logging.getLogger(__name__)

# Table 3 of the manuscript.  DoS is printed there as 16,535; the true count
# in both releases is 16,353, and the corrected figure reconciles the total.
UNSW_TABLE3 = {
    "Normal": 2_218_761, "Generic": 215_481, "Exploits": 44_525,
    "Fuzzers": 24_246, "DoS": 16_353, "Reconnaissance": 13_987,
    "Analysis": 2_677, "Backdoors": 2_329, "Shell Code": 1_511, "Worm": 174,
}
CICIDS_TOTAL = 2_830_743

UNSW_LABEL_FIXES = {
    "backdoor": "Backdoors", "backdoors": "Backdoors",
    "shellcode": "Shell Code", "shell code": "Shell Code",
    "worms": "Worm", "worm": "Worm", "dos": "DoS", "fuzzers": "Fuzzers",
    "generic": "Generic", "reconnaissance": "Reconnaissance",
    "analysis": "Analysis", "exploits": "Exploits",
}
# The four raw CSVs carry no header row.  NUSW-NB15_features.csv supplies the
# names, but it is frequently missing from redistributions, so the canonical
# 49-column order is kept here as a fallback.  Order matters: it is positional.
UNSW_COLUMNS = [
    "srcip", "sport", "dstip", "dsport", "proto", "state", "dur", "sbytes",
    "dbytes", "sttl", "dttl", "sloss", "dloss", "service", "Sload", "Dload",
    "Spkts", "Dpkts", "swin", "dwin", "stcpb", "dtcpb", "smeansz", "dmeansz",
    "trans_depth", "res_bdy_len", "Sjit", "Djit", "Stime", "Ltime",
    "Sintpkt", "Dintpkt", "tcprtt", "synack", "ackdat", "is_sm_ips_ports",
    "ct_state_ttl", "ct_flw_http_mthd", "is_ftp_login", "ct_ftp_cmd",
    "ct_srv_src", "ct_srv_dst", "ct_dst_ltm", "ct_src_ltm",
    "ct_src_dport_ltm", "ct_dst_sport_ltm", "ct_dst_src_ltm", "attack_cat",
    "Label",
]

UNSW_DROP = ["srcip", "sport", "dstip", "dsport", "Stime", "Ltime",
             "id", "label", "Label", "attack_cat"]
CICIDS_DROP = ["Flow ID", "Source IP", "Src IP", "Source Port", "Src Port",
               "Destination IP", "Dst IP", "Destination Port", "Dst Port",
               "Timestamp", "Protocol", "Fwd Header Length.1"]


# --------------------------------------------------------------------- load
def _clean(df: pd.DataFrame) -> pd.DataFrame:
    feat = [c for c in df.columns if c != "target"]
    for c in feat:
        if df[c].dtype == object or df[c].dtype == bool:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df[feat] = df[feat].replace([np.inf, -np.inf], np.nan).fillna(0.0)
    df[feat] = df[feat].astype(np.float32)
    nun = df[feat].nunique()
    const = [c for c in feat if nun[c] <= 1]
    if const:
        log.info("dropping %d constant columns", len(const))
        df = df.drop(columns=const)
    return df


def _onehot(df: pd.DataFrame, cols, min_count: int = 500) -> pd.DataFrame:
    present = [c for c in cols if c in df.columns]
    for c in present:
        vc = df[c].astype(str).value_counts()
        keep = set(vc[vc >= min_count].index)
        df[c] = np.where(df[c].astype(str).isin(keep), df[c].astype(str), "other")
    return pd.get_dummies(df, columns=present, prefix=present) if present else df


def _find(root: Path, pattern: str) -> Path | None:
    """Locate a file anywhere under root, so a download spread across
    subfolders does not have to be tidied up by hand first.

    A file sitting directly in root wins.  Otherwise the shallowest match
    wins, and if there is more than one candidate every path is logged --
    silently picking one copy of a corpus when two are present is exactly the
    kind of mistake that reaches a results table without ever announcing
    itself.
    """
    direct = root / pattern
    if direct.exists():
        return direct
    hits = sorted(root.rglob(pattern), key=lambda q: (len(q.parts), str(q)))
    if not hits:
        return None
    if len(hits) > 1:
        log.warning("  %d copies of %s found; using the shallowest:",
                    len(hits), pattern)
        for h in hits:
            log.warning("      %s %s", "->" if h is hits[0] else "  ", h)
    return hits[0]


def load_unsw_full(root: str | Path) -> pd.DataFrame:
    root = Path(root)
    parts_paths = []
    for i in (1, 2, 3, 4):
        q = _find(root, f"UNSW-NB15_{i}.csv")
        if q is None:
            raise FileNotFoundError(
                f"UNSW-NB15_{i}.csv not found anywhere under {root}. All four "
                "parts are needed; the pre-split training/testing pair is a "
                "different, smaller release -- load that with "
                "--dataset unsw-curated instead.")
        parts_paths.append(q)

    # How many columns do the CSVs actually have?  The names are applied
    # positionally, so a names list of the wrong length silently misaligns
    # every field -- the kind of error that survives all the way to a results
    # table.  Count first, then decide which naming to trust.
    ncols = pd.read_csv(parts_paths[0], header=None, nrows=1).shape[1]

    names = None
    feat_file = _find(root, "NUSW-NB15_features.csv")
    if feat_file is not None:
        fdf = pd.read_csv(feat_file, encoding="latin-1")
        col = next((c for c in fdf.columns if c.strip().lower() == "name"), None)
        if col is None:
            log.warning("  %s has no 'Name' column; ignoring it", feat_file.name)
        else:
            cand = [str(n).strip() for n in fdf[col].tolist()]
            if len(cand) != ncols:
                log.warning("  %s lists %d names but the CSVs have %d columns "
                            "-- ignoring it and using the canonical order",
                            feat_file.name, len(cand), ncols)
            elif "attack_cat" not in cand:
                log.warning("  %s has no attack_cat entry; ignoring it",
                            feat_file.name)
            else:
                names = cand
                log.info("  column names from %s (%d columns)",
                         feat_file.name, ncols)
    if names is None:
        if ncols != len(UNSW_COLUMNS):
            raise ValueError(
                f"the CSVs have {ncols} columns but the canonical UNSW-NB15 "
                f"layout has {len(UNSW_COLUMNS)}. This is not the four-part "
                "release this loader expects.")
        names = list(UNSW_COLUMNS)
        log.warning("  using the canonical 49-column order")

    frames = []
    for p in parts_paths:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            frames.append(pd.read_csv(p, header=None, names=names,
                                      low_memory=False))
        log.info("  %s -> %d rows", p.name, len(frames[-1]))
    df = pd.concat(frames, ignore_index=True)
    cat = df["attack_cat"].astype(str).str.strip().str.lower()
    cat = cat.replace({"nan": "", "none": ""})
    lab = cat.map(UNSW_LABEL_FIXES).fillna("")
    df["target"] = lab.where(lab != "", "Normal")
    df = df.drop(columns=[c for c in UNSW_DROP if c in df.columns],
                 errors="ignore")
    df = _onehot(df, ["proto", "service", "state"])
    return _clean(df)


def load_unsw_curated(root: str | Path) -> pd.DataFrame:
    root = Path(root)
    parts = []
    for fn in ("UNSW_NB15_training-set.csv", "UNSW_NB15_testing-set.csv"):
        p = _find(root, fn)
        if p is None:
            raise FileNotFoundError(f"{fn} not found anywhere under {root}")
        log.info("  %s", p)
        parts.append(pd.read_csv(p, low_memory=False))
    df = pd.concat(parts, ignore_index=True)
    df.columns = [str(c).strip().lstrip("﻿") for c in df.columns]
    # the curated release spells three classes differently from Table 3
    # ("Backdoor", "Shellcode", "Worms"); normalise so counts line up
    _c = df["attack_cat"].astype(str).str.strip().str.lower()
    _l = _c.map(UNSW_LABEL_FIXES).fillna("")
    df["target"] = _l.where(_l != "", "Normal")
    df = df.drop(columns=[c for c in UNSW_DROP if c in df.columns],
                 errors="ignore")
    df = _onehot(df, ["proto", "service", "state"])
    return _clean(df)


CICIDS_CSVS = [
    "Monday-WorkingHours.pcap_ISCX.csv",
    "Tuesday-WorkingHours.pcap_ISCX.csv",
    "Wednesday-workingHours.pcap_ISCX.csv",
    "Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv",
    "Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv",
    "Friday-WorkingHours-Morning.pcap_ISCX.csv",
    "Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv",
    "Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv",
]


def load_cicids(root: str | Path, binary: bool = True) -> pd.DataFrame:
    root = Path(root)
    frames = []
    for fn in CICIDS_CSVS:
        p = root / fn
        if not p.exists():
            cands = sorted(root.glob(fn.split("-")[0] + "*.csv"))
            if not cands:
                raise FileNotFoundError(f"{fn} not found in {root}")
            p = cands[0]
            log.warning("  %s missing, using %s", fn, p.name)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            d = pd.read_csv(p, low_memory=False, encoding="latin-1")
        d.columns = [str(c).strip() for c in d.columns]
        frames.append(d)
        log.info("  %s -> %d rows", p.name, len(d))
    df = pd.concat(frames, ignore_index=True)
    lab = df["Label"].astype(str).str.strip().replace({
        "Web Attack \x96 Brute Force": "Web Attack - Brute Force",
        "Web Attack \x96 XSS": "Web Attack - XSS",
        "Web Attack \x96 Sql Injection": "Web Attack - Sql Injection"})
    df["target"] = np.where(lab.str.upper() == "BENIGN", "BENIGN", "ATTACK") \
        if binary else lab
    df = df.drop(columns=[c for c in CICIDS_DROP + ["Label"] if c in df.columns],
                 errors="ignore")
    return _clean(df)


LOADERS = {"unsw-full": load_unsw_full,
           "unsw-curated": load_unsw_curated,
           "cicids": load_cicids}


def load(dataset: str, root: str | Path) -> pd.DataFrame:
    if dataset not in LOADERS:
        raise ValueError(f"dataset must be one of {sorted(LOADERS)}")
    df = LOADERS[dataset](root)
    log.info("%s: %d rows, %d features, %d classes",
             dataset, len(df), df.shape[1] - 1, df["target"].nunique())
    return df


def check_counts(dataset: str, df: pd.DataFrame) -> bool:
    """Compare with the manuscript before anything is trained."""
    print("=" * 66)
    print(f"  {dataset}: record counts")
    print("=" * 66)
    got = df["target"].value_counts().to_dict()
    ok = True
    if dataset.startswith("unsw"):
        print(f"  {'class':<18}{'Table 3':>12}{'found':>12}{'diff':>8}   status")
        worst = 0.0
        for k, exp in sorted(UNSW_TABLE3.items(), key=lambda kv: -kv[1]):
            f = int(got.get(k, 0))
            d = f - exp
            rel = abs(d) / max(exp, 1)
            # A handful of records either way is transcription noise in the
            # published table, not a wrong download.  A class that is absent,
            # or off by a percent, is a different corpus.
            hit = (rel < 1e-4)
            if dataset == "unsw-full":
                worst = max(worst, rel)
            status = "ok" if d == 0 else ("ok (rounding)" if hit else "MISMATCH")
            print(f"  {k:<18}{exp:>12,}{f:>12,}{d:>+8,}   {status}")
        print(f"\n  TOTAL {len(df):,}")
        if dataset == "unsw-full":
            ok = worst < 1e-4
        if dataset == "unsw-curated":
            print("\n  Note: on the curated release only the eight attack classes "
                  "match;\n  Normal and Generic were subsampled by the dataset authors.")
            ok = True
    else:
        ok = len(df) == CICIDS_TOTAL
        print(f"  TOTAL expected {CICIDS_TOTAL:,}, found {len(df):,}   "
              f"{'ok' if ok else 'MISMATCH'}")
        print("  binary split: " + ", ".join(f"{k}={v:,}" for k, v in
                                             sorted(got.items())))
        if not ok:
            print("\n  If the total is ~2.5M you have GeneratedLabelledFlows; "
                  "this pipeline\n  expects the eight MachineLearningCVE files.")
    return ok


# ------------------------------------------------------------------- folds
@dataclass
class Fold:
    fold: int
    seed: int
    clients: dict = field(default_factory=dict)
    X_val: np.ndarray = None
    y_val: np.ndarray = None
    X_test: np.ndarray = None
    y_test: np.ndarray = None
    classes: list = field(default_factory=list)
    feature_names: list = field(default_factory=list)


def dirichlet_partition(y, n_clients, alpha, rng):
    shards = {c: [] for c in range(n_clients)}
    for cls in np.unique(y):
        idx = np.where(y == cls)[0]
        rng.shuffle(idx)
        p = rng.dirichlet(np.full(n_clients, alpha))
        cuts = (np.cumsum(p)[:-1] * len(idx)).astype(int)
        for cid, part in enumerate(np.split(idx, cuts)):
            if len(part):
                shards[cid].append(part)
    return {c: (np.concatenate(v) if v else np.array([], dtype=int))
            for c, v in shards.items()}


def per_client_smote(X, y, seed, cap=None, k_neighbors=5):
    """SMOTE on one client's own shard, never across clients.

    A client can only rebalance the classes it actually observes, so globally
    rare classes stay unevenly represented across the federation. That is the
    intended difficulty, not a defect.
    """
    from imblearn.over_sampling import SMOTE
    counts = np.bincount(y)
    present = np.where(counts > 0)[0]
    if len(present) < 2:
        return X, y
    k = int(min(k_neighbors, max(1, counts[present].min() - 1)))
    viable = present[counts[present] > k]
    if len(viable) < 2:
        return X, y
    target = int(counts[present].max())
    if cap:
        target = min(target, int(cap))
    strategy = {int(c): max(int(counts[c]), target) for c in viable}
    mask = np.isin(y, viable)
    try:
        sm = SMOTE(sampling_strategy=strategy, k_neighbors=k, random_state=seed)
        Xr, yr = sm.fit_resample(X[mask], y[mask])
    except ValueError as e:
        log.warning("SMOTE skipped on a shard: %s", e)
        return X, y
    if (~mask).any():
        Xr = np.vstack([Xr, X[~mask]])
        yr = np.concatenate([yr, y[~mask]])
    return Xr.astype(np.float32), yr.astype(np.int64)


def make_folds(df, cfg, smote: bool = True) -> list[Fold]:
    """Build the folds of Section 4.1.

    `smote` is the ONLY thing the SMOTE ablation changes. Everything else --
    the split, the Dirichlet draw, the seeds, the normalisation -- is
    identical between the two arms, which is what makes the comparison a
    controlled one.
    """
    feature_names = [c for c in df.columns if c != "target"]
    classes = sorted(df["target"].unique())
    c2i = {c: i for i, c in enumerate(classes)}

    if cfg.subsample and cfg.subsample < len(df):
        frac = cfg.subsample / len(df)
        parts = []
        for _, g in df.groupby("target", sort=True):
            n = len(g) if len(g) <= 5000 else max(5000, int(round(len(g) * frac)))
            parts.append(g.sample(min(n, len(g)), random_state=0))
        df = pd.concat(parts).sample(frac=1.0, random_state=0).reset_index(drop=True)
        log.warning("subsampled to %d rows -- results are not full-corpus", len(df))

    X_all = df[feature_names].to_numpy(dtype=np.float32)
    y_all = df["target"].map(c2i).to_numpy(dtype=np.int64)

    # The splitter always cuts the corpus into 1/test_frac parts so that the
    # test partition stays at the 20% of Section 4.1 regardless of how many
    # folds are actually run; cfg.n_folds then selects how many of them to use.
    n_parts = max(2, int(round(1.0 / cfg.split[2])))
    skf = StratifiedKFold(n_splits=n_parts, shuffle=True,
                          random_state=cfg.seeds[0])
    folds = []
    for k, (trval, test_idx) in enumerate(skf.split(X_all, y_all)):
        if k >= cfg.n_folds:
            break
        seed = cfg.seeds[k % len(cfg.seeds)]
        rng = np.random.default_rng(seed)
        val_frac = cfg.split[1] / (cfg.split[0] + cfg.split[1])
        tr_idx, val_idx = train_test_split(
            trval, test_size=val_frac, stratify=y_all[trval], random_state=seed)

        lo = X_all[tr_idx].min(axis=0)
        hi = X_all[tr_idx].max(axis=0)
        span = np.where(hi > lo, hi - lo, 1.0).astype(np.float32)
        norm = lambda i: np.clip((X_all[i] - lo) / span, 0, 1).astype(np.float32)

        f = Fold(fold=k, seed=seed, classes=classes, feature_names=feature_names)
        f.X_val, f.y_val = norm(val_idx), y_all[val_idx]
        f.X_test, f.y_test = norm(test_idx), y_all[test_idx]

        for cid, local in dirichlet_partition(
                y_all[tr_idx], cfg.n_clients, cfg.alpha, rng).items():
            if len(local) < 20:
                continue
            g = tr_idx[local]
            Xc, yc = norm(g), y_all[g]
            if smote:
                Xc, yc = per_client_smote(Xc, yc, seed=seed + 1000 * cid,
                                          cap=cfg.smote_cap)
            f.clients[cid] = (Xc, yc)
        folds.append(f)
        rows = sum(len(y) for _, y in f.clients.values())
        gb = rows * len(feature_names) * 4 / 2**30
        log.info("fold %d: %d clients, %s rows after resampling (~%.1f GB), "
                 "val %d, test %d", k, len(f.clients), f"{rows:,}", gb,
                 len(f.y_val), len(f.y_test))
        if gb > 4:
            log.warning("    that is a lot of memory. Every client's shard is "
                        "held at once, so consider --smote-cap (e.g. 50000), "
                        "which bounds the per-class target.")
    return folds


def verify_split(fold: Fold, df: pd.DataFrame) -> bool:
    """The test partition must still be at the corpus's class balance.

    If it comes back balanced, resampling has leaked across the split, and
    every precision-dependent rate downstream is inflated.
    """
    full = df["target"].value_counts(normalize=True)
    test = np.bincount(fold.y_test, minlength=len(fold.classes)) / len(fold.y_test)
    worst = max(abs(full.get(c, 0) * 100 - test[i] * 100)
                for i, c in enumerate(fold.classes))
    ok = worst < 0.5
    print(f"  test-partition class drift: {worst:.3f} pp  ->  "
          f"{'ok, untouched' if ok else 'PROBLEM: test set has been rebalanced'}")
    return ok
