"""
Experiment driver for the supplementary study.

Each experiment maps onto specific reviewer comments:

  E1  component ablation          R2-h, R2-b, R1-2
  E2  feature-permutation         R1-3, R2-c
  E3  evasion attacks             R2-g
  E4  falsified validation        R1-7
  E5  mask consensus vs imbalance R2-e

Every finished run is appended to out/results.jsonl, and the driver skips any
run already present, so it can be stopped and restarted without losing work.
"""

from __future__ import annotations

import argparse
import json
import logging
import time
from pathlib import Path

import numpy as np
import torch

from dataset import load_unsw, make_folds
from fed import run_federated, evaluate, fgsm, pgd
from model import mask_consensus

OUT = Path(__file__).parent / "out"
OUT.mkdir(exist_ok=True)
RESULTS = OUT / "results.jsonl"

BASE = dict(rounds=5, gan=True, gan_steps=10, local_epochs=2, bs=512,
            trust=True, gm=True, trim=0.2, mask=True, keep_frac=0.6,
            aug_frac=0.15)

VARIANTS = {
    "full":          {},
    "no_mask":       dict(mask=False),
    "no_gan":        dict(gan=False),
    "no_trust":      dict(trust=False),
    "no_gm":         dict(gm=False),
    "fpn_only":      dict(heads=("fpn",)),
    "mlp_only":      dict(heads=("mlp",)),
    "trf_only":      dict(heads=("trf",)),
}


def done_keys() -> set:
    if not RESULTS.exists():
        return set()
    ks = set()
    for line in RESULTS.read_text().splitlines():
        if line.strip():
            r = json.loads(line)
            ks.add(r["key"])
    return ks


def record(key, exp, **fields):
    with RESULTS.open("a") as fh:
        fh.write(json.dumps({"key": key, "exp": exp, **fields}) + "\n")
    logging.warning("  recorded %s", key)


def build(df, alpha, smote, n_folds, args):
    return make_folds(df, n_clients=args.clients, n_folds=n_folds, alpha=alpha,
                      smote=smote, smote_cap=args.smote_cap,
                      subsample=args.subsample)


# --------------------------------------------------------------------- E0
def exp_reference(df, args, have):
    """Centralised reference point on the identical pipeline.

    The federated numbers are otherwise uncalibrated: a reader cannot tell
    whether a given accuracy is low because federation is hard or because the
    corpus is hard.  Pooling every client's shard and fitting a random forest
    gives the ceiling for this partition under this preprocessing.
    """
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.metrics import accuracy_score, precision_recall_fscore_support
    for f in build(df, 0.5, True, args.folds, args):
        key = f"E0|rf|f{f.fold}"
        if key in have:
            continue
        X = np.vstack([x for x, _ in f.clients.values()])
        y = np.concatenate([yy for _, yy in f.clients.values()])
        rf = RandomForestClassifier(n_estimators=100, n_jobs=2,
                                    random_state=f.seed).fit(X, y)
        p = rf.predict(f.X_test)
        pr, rc, f1, _ = precision_recall_fscore_support(
            f.y_test, p, average="macro", zero_division=0)
        record(key, "E0", variant="central_rf", fold=f.fold,
               accuracy=float(accuracy_score(f.y_test, p)),
               precision=float(pr), recall=float(rc), f1=float(f1),
               fnr=float(1 - rc))
        logging.warning("E0 central RF fold%d acc=%.4f", f.fold,
                        accuracy_score(f.y_test, p))


# --------------------------------------------------------------------- E1
def exp_ablation(df, args, have):
    folds = build(df, 0.5, True, args.folds, args)
    folds_nosm = None
    for vname, over in VARIANTS.items():
        for f in folds:
            key = f"E1|{vname}|f{f.fold}"
            if key in have:
                continue
            cfg = {**BASE, **over}
            t = time.time()
            model, res = run_federated(f, cfg)
            res.pop("history", None)
            record(key, "E1", variant=vname, **res)
            if vname == "full" and f.fold == 0:
                torch.save({"sd": model.state_dict(),
                            "mask": model.feature_mask.clone(),
                            "d_in": f.X_val.shape[1],
                            "classes": f.classes,
                            "heads": model.heads_used},
                           OUT / "full_f0.pt")
                np.savez_compressed(OUT / "fold0_test.npz",
                                    X=f.X_test, y=f.y_test,
                                    features=np.array(f.feature_names))
            logging.warning("E1 %s fold%d acc=%.4f (%.0fs)",
                            vname, f.fold, res["accuracy"], time.time() - t)

    # the no-SMOTE variant needs its own folds
    for f in build(df, 0.5, False, args.folds, args):
        key = f"E1|no_smote|f{f.fold}"
        if key in have:
            continue
        model, res = run_federated(f, dict(BASE))
        res.pop("history", None)
        record(key, "E1", variant="no_smote", **res)
        logging.warning("E1 no_smote fold%d acc=%.4f", f.fold, res["accuracy"])


# --------------------------------------------------------------------- E2
def exp_permutation(df, args, have):
    if "E2|perm" in have:
        return
    ck = OUT / "full_f0.pt"
    if not ck.exists():
        logging.warning("E2 skipped: no trained checkpoint yet")
        return
    from model import MC3GRAM
    blob = torch.load(ck, weights_only=False)
    d = np.load(OUT / "fold0_test.npz", allow_pickle=True)
    X, y, names = d["X"], d["y"], [str(s) for s in d["features"]]
    model = MC3GRAM(blob["d_in"], len(blob["classes"]), heads=blob["heads"])
    model.load_state_dict(blob["sd"])
    model.feature_mask.copy_(blob["mask"])

    rng = np.random.default_rng(0)
    sub = rng.choice(len(X), size=min(8000, len(X)), replace=False)
    Xs, ys = X[sub], y[sub]
    base = evaluate(model, Xs, ys)["accuracy"]

    rows = []
    for j in range(X.shape[1]):
        Xp = Xs.copy()
        Xp[:, j] = Xs[rng.permutation(len(Xs)), j]
        a = evaluate(model, Xp, ys)["accuracy"]
        rows.append({"feature": names[j], "idx": j,
                     "drop": float(base - a),
                     "in_mask": bool(blob["mask"][j].item() > 0)})
    attr = model.attribution(torch.from_numpy(Xs[:2000]))
    mean_attr = torch.stack(list(attr.values())).mean(0)
    for r in rows:
        r["attribution"] = float(mean_attr[r["idx"]].item())
    record("E2|perm", "E2", baseline=base, rows=rows)


# --------------------------------------------------------------------- E3
def exp_evasion(df, args, have):
    ck = OUT / "full_f0.pt"
    if not ck.exists():
        logging.warning("E3 skipped: no trained checkpoint yet")
        return
    from model import MC3GRAM
    blob = torch.load(ck, weights_only=False)
    d = np.load(OUT / "fold0_test.npz", allow_pickle=True)
    X, y = d["X"], d["y"]
    rng = np.random.default_rng(1)
    sub = rng.choice(len(X), size=min(6000, len(X)), replace=False)
    Xs, ys = X[sub], y[sub]

    for use_mask in (True, False):
        model = MC3GRAM(blob["d_in"], len(blob["classes"]), heads=blob["heads"])
        model.load_state_dict(blob["sd"])
        # feature_mask is a registered buffer, so load_state_dict already
        # restored the learned mask.  The no-mask arm must therefore reset it
        # explicitly -- relying on the constructor's default would silently
        # compare the model against itself.
        if use_mask:
            model.feature_mask.copy_(blob["mask"])
        else:
            model.feature_mask.fill_(1.0)
        tag = "mask" if use_mask else "nomask"
        for eps in (0.0, 0.01, 0.05, 0.10):
            for atk in ("fgsm", "pgd"):
                key = f"E3|{tag}|{atk}|{eps}"
                if key in have:
                    continue
                if eps == 0.0:
                    Xa = Xs
                else:
                    Xa = fgsm(model, Xs, ys, eps) if atk == "fgsm" \
                        else pgd(model, Xs, ys, eps)
                r = evaluate(model, Xa, ys)
                record(key, "E3", defence=tag, attack=atk, eps=eps, **r)
                logging.warning("E3 %s %s eps=%.2f acc=%.4f", tag, atk, eps,
                                r["accuracy"])


# --------------------------------------------------------------------- E4
def exp_falsified(df, args, have):
    folds = build(df, 0.5, True, min(2, args.folds), args)
    for mal in (0.0, 0.1, 0.2, 0.3):
        for defence in (True, False):
            for f in folds:
                tag = "on" if defence else "off"
                key = f"E4|{tag}|{mal}|f{f.fold}"
                if key in have:
                    continue
                cfg = {**BASE, "mal_frac": mal,
                       "attack": "falsified_validation",
                       "falsified_acc": 0.99, "poison_scale": 1.0,
                       "trust": defence, "gm": defence,
                       "trim": 0.2 if defence else 0.0}
                model, res = run_federated(f, cfg)
                hist = res.pop("history", [])
                record(key, "E4", defence=tag, mal_frac=mal,
                       mal_weight=float(np.mean([h["mal_weight"] for h in hist]))
                       if hist else 0.0, **res)
                logging.warning("E4 defence=%s mal=%.1f fold%d acc=%.4f",
                                tag, mal, f.fold, res["accuracy"])


# --------------------------------------------------------------------- E5
def exp_imbalance(df, args, have):
    for alpha in (0.1, 0.5, 5.0):
        for f in build(df, alpha, True, min(2, args.folds), args):
            key = f"E5|{alpha}|f{f.fold}"
            if key in have:
                continue
            model, res = run_federated(f, dict(BASE))
            res.pop("history", None)
            record(key, "E5", alpha=alpha, **res)
            logging.warning("E5 alpha=%.1f fold%d acc=%.4f agree=%.3f",
                            alpha, f.fold, res["accuracy"], res["agreement"])


# --------------------------------------------------------------------- E6
def exp_feature_order(df, args, have):
    """Does the semantic column ordering matter to the convolutional head?

    Reviewer 1's comment 3 asks for this specifically, and it is a different
    question from the permutation-importance study of E2: here the column
    ORDER is shuffled and the model retrained, so every feature is still
    present and only adjacency changes.  A convolution that genuinely exploits
    the semantic grouping should lose accuracy; one that does not is simply a
    parameter-shared local mixer, which is the weaker claim the manuscript
    makes.  The FPN-only variant is used so the effect is not diluted by the
    two heads that carry no locality assumption.
    """
    folds = build(df, 0.5, True, args.folds, args)
    for f in folds:
        key = f"E6|shuffled|f{f.fold}"
        if key in have:
            continue
        rng = np.random.default_rng(1000 + f.fold)
        perm = rng.permutation(f.X_val.shape[1])
        g = type(f)(fold=f.fold, seed=f.seed, classes=f.classes,
                    feature_names=[f.feature_names[i] for i in perm])
        g.X_val, g.y_val = f.X_val[:, perm], f.y_val
        g.X_test, g.y_test = f.X_test[:, perm], f.y_test
        g.clients = {c: (X[:, perm], y) for c, (X, y) in f.clients.items()}
        model, res = run_federated(g, {**BASE, "heads": ("fpn",)})
        res.pop("history", None)
        record(key, "E6", variant="fpn_shuffled_order", **res)
        logging.warning("E6 shuffled-order fold%d acc=%.4f", f.fold,
                        res["accuracy"])


# --------------------------------------------------------------------- E7
AGG_RULES = {
    "krum": dict(rule="krum"),
    "trimmed_mean": dict(rule="trimmed_mean"),
}


def exp_agg_rules(df, args, have):
    """Published Byzantine-robust aggregators under the same attack.

    Reviewer 1's comment 7 asks for the trust mechanism to be evaluated
    against falsifying adversaries; E4 answered that against undefended
    aggregation only.  Krum and coordinate-wise Trimmed Mean are the obvious
    points of comparison, and neither reads the reported validation score at
    all -- so they are robust to this attack by construction, and the question
    is what that robustness costs on the clean federation.
    """
    folds = build(df, 0.5, True, min(2, args.folds), args)
    for rname, over in AGG_RULES.items():
        for mal in (0.0, 0.1, 0.2, 0.3):
            for f in folds:
                key = f"E7|{rname}|{mal}|f{f.fold}"
                if key in have:
                    continue
                cfg = {**BASE, **over, "mal_frac": mal,
                       "attack": "falsified_validation",
                       "falsified_acc": 0.99, "poison_scale": 1.0}
                model, res = run_federated(f, cfg)
                hist = res.pop("history", [])
                record(key, "E7", rule=rname, mal_frac=mal,
                       mal_weight=float(np.mean([h["mal_weight"] for h in hist]))
                       if hist else 0.0, **res)
                logging.warning("E7 %s mal=%.1f fold%d acc=%.4f",
                                rname, mal, f.fold, res["accuracy"])


# --------------------------------------------------------------------- E8
def exp_cw(df, args, have):
    """L2 Carlini-Wagner, the attack Reviewer 2's comment g still lacked."""
    ck = OUT / "full_f0.pt"
    if not ck.exists():
        logging.warning("E8 skipped: no trained checkpoint")
        return
    from model import MC3GRAM
    from fed import carlini_wagner
    blob = torch.load(ck, weights_only=False)
    d = np.load(OUT / "fold0_test.npz", allow_pickle=True)
    X, y = d["X"], d["y"]
    rng = np.random.default_rng(1)
    sub = rng.choice(len(X), size=min(2000, len(X)), replace=False)
    Xs, ys = X[sub], y[sub]

    for use_mask in (True, False):
        tag = "mask" if use_mask else "nomask"
        for c in (0.1, 1.0, 10.0):
            key = f"E8|{tag}|cw|{c}"
            if key in have:
                continue
            model = MC3GRAM(blob["d_in"], len(blob["classes"]),
                            heads=blob["heads"])
            model.load_state_dict(blob["sd"])
            if use_mask:
                model.feature_mask.copy_(blob["mask"])
            else:
                model.feature_mask.fill_(1.0)
            Xa = carlini_wagner(model, Xs, ys, steps=60, c=c)
            l2 = float(np.sqrt(((Xa - Xs) ** 2).sum(1)).mean())
            r = evaluate(model, Xa, ys)
            record(key, "E8", defence=tag, attack="cw", c=c,
                   mean_l2=l2, **r)
            logging.warning("E8 %s c=%.1f acc=%.4f meanL2=%.4f",
                            tag, c, r["accuracy"], l2)


# --------------------------------------------------------------------- E9
def exp_wasserstein(df, args, have):
    """How often does the soft xi-hinge actually let W1 exceed xi?

    Section 4.4 applies a hinge at xi = 0.05 on the critic-estimated
    1-Wasserstein distance.  A hinge is a soft term, so it penalises
    violations without preventing them, and the manuscript reports no
    distribution of observed distances -- the logs from the original runs were
    not retained.  This run applies the same hinge in the reimplementation and
    records every per-batch W1, so the mean, spread, maximum and violation
    rate can be stated as measurements.
    """
    folds = build(df, 0.5, True, args.folds, args)
    for xi in (0.05, 0.10):
        for f in folds:
            key = f"E9|xi{xi}|f{f.fold}"
            if key in have:
                continue
            cfg = {**BASE, "xi": xi, "gamma": 0.5}
            model, res = run_federated(f, cfg)
            res.pop("history", None)
            record(key, "E9", **res)
            logging.warning("E9 xi=%.2f fold%d  W1 mean=%.4f max=%.4f "
                            "violations=%.1f%% over %d batches",
                            xi, f.fold, res.get("w1_mean", float("nan")),
                            res.get("w1_max", float("nan")),
                            100 * res.get("w1_violation_rate", float("nan")),
                            res.get("w1_batches", 0))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--exp", nargs="+",
                    default=["E0", "E1", "E2", "E3", "E4", "E5", "E6", "E7", "E8", "E9"])
    ap.add_argument("--root", default=str(Path(__file__).parent / "data"))
    ap.add_argument("--clients", type=int, default=10)
    ap.add_argument("--folds", type=int, default=3)
    ap.add_argument("--subsample", type=int, default=60_000)
    ap.add_argument("--smote-cap", type=int, default=8_000)
    ap.add_argument("--rounds", type=int, default=5)
    args = ap.parse_args()

    logging.basicConfig(level=logging.WARNING, format="%(asctime)s %(message)s",
                        datefmt="%H:%M:%S")
    BASE["rounds"] = args.rounds

    df = load_unsw(args.root, verbose=False)
    logging.warning("corpus %d rows, %d features", len(df), df.shape[1] - 1)

    fns = {"E0": exp_reference, "E1": exp_ablation, "E2": exp_permutation,
           "E3": exp_evasion, "E4": exp_falsified, "E5": exp_imbalance,
           "E6": exp_feature_order,
           "E7": exp_agg_rules, "E8": exp_cw,
           "E9": exp_wasserstein}
    for e in args.exp:
        have = done_keys()
        logging.warning("=== %s (%d runs already done) ===", e, len(have))
        fns[e](df, args, have)
    logging.warning("all requested experiments complete")


if __name__ == "__main__":
    main()
