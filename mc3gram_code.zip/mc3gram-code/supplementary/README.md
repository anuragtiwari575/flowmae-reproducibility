# MC³-GRAM supplementary study

Everything needed to reproduce the supplementary tables, and to re-run the
same study at a larger scale on Kaggle.

## What this is, and what it is not

This is an independent reimplementation built from the equations in the
manuscript. It is **not** the code that produced Tables 6–22. Its absolute
rates do not reproduce those, and are not meant to: different code, different
seeds, a smaller corpus partition and a much shorter schedule.

What it *is* powered to do is compare configurations that share a protocol —
which is exactly what every open reviewer comment reduces to. Read comparisons
within a table; do not read comparisons between these tables and the main
results.

## Corpus

The curated ten-class UNSW-NB15 partition (`UNSW_NB15_training-set.csv` +
`UNSW_NB15_testing-set.csv`, 257,673 records pooled and re-split here).

Every attack class is carried over whole from the full capture, so eight of
the ten counts match the manuscript's Table 3 exactly. Only Normal (93,000)
and Generic (58,871) were subsampled by the dataset authors.

Note that Normal is 36% of this partition against 87% of the full capture, so
aggregate accuracy here is necessarily lower than on the full corpus,
independently of any modelling choice. `exp_reference` fits a centralised
random forest on the identical pipeline to give the ceiling — it lands at
0.778 ± 0.002 accuracy, which is the number against which the federated
results should be read.

## Layout

```
dataset.py     loading, 70/10/20 split, Dirichlet partition, per-client SMOTE
model.py       stem, three heads, Jacobian attribution, mask consensus, GAN
fed.py         local training, trust weighting, trimmed geometric median,
               evasion attacks, evaluation
run.py         the six experiments; appends to out/results.jsonl
tables.py      results.jsonl -> LaTeX, with the identity checks
prevalence.py  recovers the test-partition class distribution from the
               manuscript's own printed rates (no data needed)
```

## Running

```bash
pip install torch numpy pandas scikit-learn imbalanced-learn scipy
python run.py --exp E0 E1 E2 E3 E4 E5
python tables.py
```

`run.py` appends each finished run to `out/results.jsonl` and skips anything
already recorded, so it can be stopped and restarted freely. To run two
streams side by side on a small machine:

```bash
MC3_THREADS=1 python run.py --exp E1 &
MC3_THREADS=1 python run.py --exp E4 &
```

Experiments are disjoint by key, so parallel streams do not duplicate work.

## The experiments

| | Question | Reviewer |
|---|---|---|
| E0 | What is the ceiling on this partition? | calibration |
| E1 | What does each component contribute? | R2-h, R2-b, R1-2 |
| E2 | Does the mask retain the features that matter? | R1-3, R2-c |
| E3 | What happens under FGSM and PGD? | R2-g |
| E4 | What does a client gain by lying about its validation score? | R1-7 |
| E5 | How does mask consensus behave as skew varies? | R2-e |

E1 also records every model's rates **twice** — on a test partition at the
corpus class balance, and on an equal-support subset of that same partition.
The gap is the inflation attributable to the balanced-test protocol alone,
which is what Section 4.13 previously acknowledged without measuring.

## Identity checks

`tables.py` refuses to write anything if a row violates

```
FNR = 1 - Recall            enforced, and true by construction
F1  = 2PR/(P+R)             reported; macro-F1 is the mean of per-class F1,
                            so this is a diagnostic rather than an identity
```

FNR is derived from recall rather than measured separately, which is what
makes the first identity hold by construction rather than by transcription —
the failure mode that produced the defects found in the current draft.

## Running this on Kaggle at full scale

Three changes and it is Kaggle-safe:

1. **Paths.** `/kaggle/input/...` is read-only; write everything to
   `/kaggle/working/`. Point `--root` at the attached dataset and leave
   `out/` under `/kaggle/working`.
2. **Checkpointing** is already there — `out/results.jsonl` is the resume
   state. Keep it under `/kaggle/working` so a session restart resumes rather
   than starts over.
3. **Memory.** `make_folds` materialises every client's SMOTE'd shard at once.
   That is fine at this scale (~350k rows pooled) but will not be on the full
   2.54M capture; stream clients one at a time there, or keep `--smote-cap`.

Watch the dataset you attach: the full four-part release
(`UNSW-NB15_1..4.csv` + `NUSW-NB15_features.csv`, 2.54M records) and the
curated partition used here are different corpora and are not comparable.

## Two open protocol questions

Neither can be resolved from the manuscript, and both affect how a scaled-up
run should be configured.

1. **What was the SMOTE target?** Section 4.5 says balancing reached
   "approximately 215,481 samples per class" — that is the Generic count in
   the full capture, not Normal's 2,218,761. So either Normal was capped, or
   the target was the largest *attack* class. The two give very different
   shard sizes.
2. **Which corpus did Section 4.9 use?** The poisoning and backdoor
   experiments never name one, and the falsified-validation sweep should run
   on the same corpus.
