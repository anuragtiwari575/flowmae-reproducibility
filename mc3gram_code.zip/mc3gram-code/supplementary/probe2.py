import logging, time
logging.basicConfig(level=logging.WARNING)
from dataset import load_unsw, make_folds
from fed import run_federated
df = load_unsw("data", verbose=False)
f = make_folds(df, n_clients=10, n_folds=1, alpha=0.5, smote=True,
               smote_cap=8000, subsample=80000)[0]
t=time.time()
m,r = run_federated(f, dict(rounds=6, gan=True, gan_steps=15, local_epochs=2))
print("LayerNorm+GAN 6-round secs", round(time.time()-t,1), flush=True)
print("curve", [round(h['val'],4) for h in r['history']], flush=True)
print("test", {k:round(v,4) for k,v in r.items() if k in ('accuracy','precision','recall','f1','fnr','agreement','mask_kept')}, flush=True)
t=time.time()
m,r = run_federated(f, dict(rounds=6, gan=False, local_epochs=2))
print("LayerNorm noGAN 6-round secs", round(time.time()-t,1), flush=True)
print("curve", [round(h['val'],4) for h in r['history']], flush=True)
print("test", {k:round(v,4) for k,v in r.items() if k in ('accuracy','precision','recall','f1','fnr','agreement','mask_kept')}, flush=True)
