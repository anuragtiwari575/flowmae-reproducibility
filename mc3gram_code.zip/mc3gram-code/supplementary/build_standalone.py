"""
Build a standalone PDF of the supplementary section.

`supplementary.tex` is written to be \\input into the manuscript, so it refers
to the manuscript's own labels.  For a standalone preview those references
cannot resolve, so they are replaced here with the literal numbers they point
at.  The version that goes into the paper keeps the \\ref{} calls.
"""

from __future__ import annotations

import re
import subprocess
from pathlib import Path

HERE = Path(__file__).parent
OUT = HERE / "out"

# manuscript label -> what it is called in the manuscript
EXTERNAL = {
    "sec:method": "Section 3",
    "sec:limitations": "Section 4.13",
    "sec:plausibility": "Section 4.7",
    "tab:unsw": "Table 3",
    "tab:unsw10": "Table 6",
    "tab:unsw30": "Table 8",
    "tab:ablation_cicids": "Table 22",
    "eq:attribution": "(20)",
}

PREAMBLE = r"""\documentclass[11pt,a4paper]{article}
\usepackage[margin=25mm]{geometry}
\usepackage{amsmath,amssymb}
\usepackage{booktabs}
\usepackage[colorlinks=true,linkcolor=blue,citecolor=blue]{hyperref}
\usepackage{parskip}
\setcounter{secnumdepth}{3}
\renewcommand{\thesection}{S\arabic{section}}
\title{Supplementary material\\[2mm]
\large A Generative-Augmented Federated Learning Framework for Intrusion
Detection with Multi-Head Feature Masking and Robust Aggregation}
\date{}
\begin{document}
\maketitle
"""


def main() -> int:
    src = (OUT / "supplementary.tex").read_text()
    tables = (OUT / "supplementary_tables.tex").read_text()

    # Only the real \input at line start -- the header comment mentions the
    # same command, and replacing that one splices the tables into a comment.
    body = re.sub(r"(?m)^\\input\{supplementary_tables\}\s*$", lambda _: tables, src)

    # resolve references that point into the manuscript
    for label, text in EXTERNAL.items():
        body = re.sub(r"(?:Section|Table|Equation)?~?\\(?:eq)?ref\{"
                      + re.escape(label) + r"\}", text, body)
        body = body.replace("\\eqref{" + label + "}", text)

    # anything still pointing outside this document would typeset as '??'
    leftover = re.findall(r"\\(?:eq)?ref\{([^}]*)\}", body)
    unresolved = [l for l in leftover if not l.startswith(("tab:supp", "sec:supp"))]
    if unresolved:
        print("unresolved external refs:", sorted(set(unresolved)))

    doc = PREAMBLE + body + "\n\\end{document}\n"
    path = OUT / "supplementary_standalone.tex"
    path.write_text(doc)

    for _ in range(2):
        r = subprocess.run(
            ["pdflatex", "-interaction=nonstopmode", path.name],
            cwd=OUT, capture_output=True, text=True)
    errs = [l for l in r.stdout.splitlines() if l.startswith("!")]
    print(f"pdflatex exit {r.returncode}, {len(errs)} errors")
    for e in errs[:10]:
        print("  ", e)
    pdf = OUT / "supplementary_standalone.pdf"
    print("wrote", pdf, pdf.exists() and f"({pdf.stat().st_size//1024} KB)")
    return 0 if pdf.exists() else 1


if __name__ == "__main__":
    raise SystemExit(main())
