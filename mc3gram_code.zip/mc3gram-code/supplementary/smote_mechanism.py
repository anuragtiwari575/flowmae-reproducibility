"""
Does any plausible resampling scheme reproduce the recovered test-partition
proportions?

The limitations section currently says the recovered proportions show that
"resampling reached this test partition as well".  That is a claim about
mechanism, and it should not be made unless a mechanism actually produces
those proportions.  This script checks.

Candidates are the schemes anyone would actually run: leave it alone; SMOTE
every class up to the largest; SMOTE every minority class up to a target T,
sweeping T; and cap the majority while lifting the minorities.  Each is
scored by total variation distance from the recovered proportions.
"""

from __future__ import annotations

import numpy as np

# recovered from Tables 6-8 (see prevalence.py)
RECOVERED = {
    "Normal": 0.2900, "Fuzzers": 0.1911, "Backdoors": 0.1520, "DoS": 0.1207,
    "Exploits": 0.0892, "Generic": 0.0560, "Reconnaissance": 0.0419,
    "Shell Code": 0.0229, "Analysis": 0.0216, "Worm": 0.0106,
}

# curated ten-class partition (what the attack counts in Table 3 match)
CURATED = {
    "Normal": 93_000, "Generic": 58_871, "Exploits": 44_525, "Fuzzers": 24_246,
    "DoS": 16_353, "Reconnaissance": 13_987, "Analysis": 2_677,
    "Backdoors": 2_329, "Shell Code": 1_511, "Worm": 174,
}

# full capture (Table 3's own figures)
FULL = dict(CURATED, Normal=2_218_761, Generic=215_481)

CLASSES = list(RECOVERED)


def tv(p: dict, q: dict) -> float:
    """Total variation distance between two class distributions."""
    return 0.5 * sum(abs(p[c] - q[c]) for c in CLASSES)


def norm(counts: dict) -> dict:
    t = sum(counts.values())
    return {c: counts[c] / t for c in CLASSES}


def smote_to_max(counts):
    m = max(counts.values())
    return {c: m for c in CLASSES}


def smote_to_target(counts, T):
    """Every class below T is lifted to T; classes above it are untouched."""
    return {c: max(counts[c], T) for c in CLASSES}


def cap_and_lift(counts, cap, T):
    """Majority classes capped at `cap`, minorities lifted to T."""
    return {c: min(max(counts[c], T), cap) for c in CLASSES}


def main():
    print(f"{'scheme':<44}{'TV distance':>12}")
    print("-" * 56)
    results = []

    for base_name, base in (("curated 257k", CURATED), ("full capture", FULL)):
        results.append((f"{base_name}: untouched (natural)", tv(norm(base), RECOVERED)))
        results.append((f"{base_name}: SMOTE all to max (balanced)",
                        tv(norm(smote_to_max(base)), RECOVERED)))
        best = None
        for T in range(200, 250_000, 200):
            d = tv(norm(smote_to_target(base, T)), RECOVERED)
            if best is None or d < best[0]:
                best = (d, T)
        results.append((f"{base_name}: SMOTE minorities to T (best T={best[1]:,})",
                        best[0]))
        best2 = None
        for cap in range(2_000, 300_000, 2_000):
            for T in range(200, min(cap, 250_000), 2_000):
                d = tv(norm(cap_and_lift(base, cap, T)), RECOVERED)
                if best2 is None or d < best2[0]:
                    best2 = (d, cap, T)
        results.append((f"{base_name}: cap {best2[1]:,} + lift to {best2[2]:,}",
                        best2[0]))

    for name, d in results:
        print(f"{name:<44}{d:>12.4f}")

    print()
    print("A TV distance of 0 is an exact match; 0.05 or below would be a")
    print("convincing one.  For reference, two unrelated ten-class")
    print("distributions typically sit around 0.5.")
    print()
    print(f"{'class':<16}{'recovered':>10}{'curated':>10}{'full':>10}"
          f"{'balanced':>10}")
    nc, nf = norm(CURATED), norm(FULL)
    for c in sorted(CLASSES, key=lambda x: -RECOVERED[x]):
        print(f"{c:<16}{RECOVERED[c]:>10.4f}{nc[c]:>10.4f}{nf[c]:>10.5f}"
              f"{0.10:>10.2f}")
    print()
    print("Read the ordering, not just the distances: Generic is the second")
    print("largest class in every candidate corpus but sixth in the recovered")
    print("proportions, and Backdoors is eighth in the corpus but third here.")
    print("No scheme that lifts or caps classes by size can invert that order.")


if __name__ == "__main__":
    main()
