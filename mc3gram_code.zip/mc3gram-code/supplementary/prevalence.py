"""
Recover the test-partition class distribution from the manuscript's own
one-vs-rest rates.

For class c with prevalence p, one-vs-rest accuracy and precision are

    Acc  = R*p + (1-F)(1-p)                  ... (i)
    Prec = R*p / (R*p + F*(1-p))             ... (ii)

with R the recall and F the FPR as printed.  Either equation determines p on
its own, so solving both and comparing is a consistency check that does not
depend on any assumption about how the partition was built.  Summing the
recovered prevalences over the ten classes is a second, independent check: if
the rows come from one confusion matrix over one test partition, they must
sum to 1.

This settles, from the printed numbers alone, whether that partition was
class-balanced (every p = 0.10), at the corpus's natural distribution
(Normal = 0.87, Worm = 0.00007), or something else.
"""

from __future__ import annotations


# Tables 6-8: class, accuracy, precision, recall, FPR, FNR
UNSW10 = [
    ("Normal",     0.9899, 0.9824, 0.9828, 0.0072, 0.0172),
    ("Fuzzers",    0.9905, 0.9782, 0.9723, 0.0052, 0.0277),
    ("Analysis",   0.9880, 0.7144, 0.7392, 0.0065, 0.2608),
    ("Backdoors",  0.9853, 0.9749, 0.9267, 0.0042, 0.0733),
    ("DoS",        0.9867, 0.9629, 0.9255, 0.0049, 0.0745),
    ("Exploits",   0.9888, 0.9441, 0.9306, 0.0055, 0.0694),
    ("Generic",    0.9928, 0.9106, 0.9692, 0.0058, 0.0308),
    ("Reconn.",    0.9915, 0.8719, 0.9320, 0.0059, 0.0680),
    ("Shell Code", 0.9890, 0.7269, 0.8354, 0.0074, 0.1646),
    ("Worm",       0.9920, 0.5843, 0.7954, 0.0059, 0.2046),
]

NATURAL = {   # full-capture proportions, for comparison
    "Normal": 0.8735, "Generic": 0.0848, "Exploits": 0.0175, "Fuzzers": 0.0095,
    "DoS": 0.0064, "Reconn.": 0.0055, "Analysis": 0.0011, "Backdoors": 0.0009,
    "Shell Code": 0.0006, "Worm": 0.00007,
}


def p_from_accuracy(acc, rec, fpr):
    """Solve (i) for p.  Acc = (1-F) - p((1-F) - R)."""
    denom = (1 - fpr) - rec
    if abs(denom) < 1e-9:
        return None
    return ((1 - fpr) - acc) / denom


def p_from_precision(prec, rec, fpr):
    """Solve (ii) for p.  Prec = Rp / (Rp + F(1-p))."""
    if prec <= 0 or rec <= 0:
        return None
    # Rp(1-Prec) = Prec*F*(1-p)  ->  p (R(1-Prec) + Prec*F) = Prec*F
    num = prec * fpr
    den = rec * (1 - prec) + prec * fpr
    if abs(den) < 1e-12:
        return None
    return num / den


def main():
    print(f"{'class':<12}{'p (from Acc)':>14}{'p (from Prec)':>15}"
          f"{'agreement':>12}{'natural':>10}")
    tot_a = tot_p = 0.0
    for name, acc, prec, rec, fpr, _ in UNSW10:
        pa = p_from_accuracy(acc, rec, fpr)
        pp = p_from_precision(prec, rec, fpr)
        tot_a += pa or 0
        tot_p += pp or 0
        gap = abs(pa - pp) if (pa and pp) else float("nan")
        print(f"{name:<12}{pa:>13.4f} {pp:>14.4f} {gap:>11.4f}"
              f"{NATURAL[name]:>10.4f}")
    print("-" * 63)
    print(f"{'SUM':<12}{tot_a:>13.4f} {tot_p:>14.4f}")
    print()
    print("A sum near 1.0 means the ten rows are mutually consistent as")
    print("one-vs-rest views of a single test partition.")
    print("Every p near 0.10 would mean that partition was class-balanced.")
    print("p matching the 'natural' column would mean it was left untouched.")


if __name__ == "__main__":
    main()
