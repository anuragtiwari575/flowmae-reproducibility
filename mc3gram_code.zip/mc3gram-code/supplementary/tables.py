"""
Turn out/results.jsonl into LaTeX tables, and check them before writing.

Two identities are enforced on every row that carries the four rates, because
they are what exposed the transcription defects in the current draft:

    FNR = 1 - Recall
    F1  = 2 P R / (P + R)

Nothing is written if a row fails, so a table cannot leave this script in a
state a reviewer can falsify with a calculator.
"""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

import numpy as np

OUT = Path(__file__).parent / "out"
RESULTS = OUT / "results.jsonl"
TEX = OUT / "supplementary_tables.tex"


def load():
    rows = []
    for line in RESULTS.read_text().splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def check_identities(rows) -> list[str]:
    bad = []
    for r in rows:
        if not all(k in r for k in ("precision", "recall", "f1", "fnr")):
            continue
        p, rc, f1, fnr = r["precision"], r["recall"], r["f1"], r["fnr"]
        if abs(fnr - (1 - rc)) > 5e-4:
            bad.append(f"{r['key']}: FNR {fnr:.4f} != 1-R {1-rc:.4f}")
        if p + rc > 0:
            f1e = 2 * p * rc / (p + rc)
            # macro-F1 is the mean of per-class F1, not F1 of the macro P and R,
            # so this is reported rather than enforced.
            r["_f1_from_pr"] = f1e
    return bad


def agg(rows, keyfn, fields=("accuracy", "precision", "recall", "f1", "fnr")):
    g = defaultdict(list)
    for r in rows:
        g[keyfn(r)].append(r)
    out = {}
    for k, rs in g.items():
        out[k] = {f: (float(np.mean([r[f] for r in rs])),
                      float(np.std([r[f] for r in rs])))
                  for f in fields if f in rs[0]}
        out[k]["n"] = len(rs)
        if "agreement" in rs[0]:
            out[k]["agreement"] = (float(np.mean([r["agreement"] for r in rs])),
                                   float(np.std([r["agreement"] for r in rs])))
        if "mal_weight" in rs[0]:
            out[k]["mal_weight"] = (float(np.mean([r["mal_weight"] for r in rs])),
                                    float(np.std([r["mal_weight"] for r in rs])))
    return out


def ms(t, d=4):
    """Mean to four places, spread to three -- the spread never needs the
    fourth, and the table does not fit the Springer text block with it."""
    return f"{t[0]:.{d}f}\\,$\\pm$\\,{t[1]:.3f}"


LABEL = {
    "central_rf": "Centralised RF (reference)",
    "full": "Full MC$^3$-GRAM",
    "no_mask": "\\quad w/o mask consensus",
    "no_gan": "\\quad w/o generative aug.",
    "no_smote": "\\quad w/o per-client SMOTE",
    "no_trust": "\\quad w/o trust weighting",
    "no_gm": "\\quad w/o trimmed geo.\\ median",
    "fpn_only": "\\quad FPN head only",
    "mlp_only": "\\quad Residual-MLP only",
    "trf_only": "\\quad Transformer head only",
}
ORDER = ["central_rf", "full", "no_mask", "no_gan", "no_smote", "no_trust",
         "no_gm", "fpn_only", "mlp_only", "trf_only"]


def t_ablation(rows):
    rs = [r for r in rows if r["exp"] in ("E0", "E1")]
    if not rs:
        return ""
    a = agg(rs, lambda r: r["variant"])
    n = max(v["n"] for v in a.values())
    L = [
        "\\begin{table}[htbp]", "\\centering",
        "\\caption{Component ablation of MC$^3$-GRAM on the curated UNSW-NB15 "
        f"partition (ten classes, macro-averaged, mean $\\pm$ s.d. over {n} folds). "
        "Each row removes exactly one component from the full model. "
        "FNR is reported as $1-\\mathrm{Recall}$ by definition.}",
        "\\label{tab:supp_ablation}",
        "\\begin{tabular}{lccccc}", "\\hline",
        "Configuration & Accuracy & Precision & Recall & F1 & FNR \\\\", "\\hline",
    ]
    for v in ORDER:
        if v not in a:
            continue
        d = a[v]
        L.append(f"{LABEL[v]} & {ms(d['accuracy'])} & {ms(d['precision'])} & "
                 f"{ms(d['recall'])} & {ms(d['f1'])} & {ms(d['fnr'])} \\\\")
        if v in ("central_rf", "full"):
            L.append("\\hline")
    L += ["\\hline", "\\end{tabular}", "\\end{table}", ""]
    return "\n".join(L)


def t_balanced(rows):
    """The quantity Section 4.13 currently acknowledges without measuring."""
    rs = [r for r in rows if r["exp"] == "E1" and "bal_accuracy" in r]
    if not rs:
        return ""
    a = agg(rs, lambda r: r["variant"],
            fields=("accuracy", "f1", "fnr", "bal_accuracy", "bal_f1", "bal_fnr"))
    npc = int(np.median([r.get("bal_n_per_class", 0) for r in rs]))
    L = [
        "\\begin{table}[htbp]", "\\centering",
        "\\caption{The same trained models evaluated twice: on a test partition "
        "left at the corpus class balance, and on an equal-support subset of "
        f"that same partition ({npc} records per class, the limit set by Worm). "
        "The gap is the inflation attributable to the balanced-test protocol "
        "alone, since the model, the training data and the split are identical.}",
        "\\label{tab:supp_balanced}",
        "\\begin{tabular}{lcccccc}", "\\hline",
        "& \\multicolumn{3}{c}{Natural balance} & \\multicolumn{3}{c}{Equal support} \\\\",
        "Configuration & Acc. & F1 & FNR & Acc. & F1 & FNR \\\\", "\\hline",
    ]
    for v in ORDER:
        if v not in a or "bal_accuracy" not in a[v]:
            continue
        d = a[v]
        L.append(f"{LABEL[v]} & {d['accuracy'][0]:.4f} & {d['f1'][0]:.4f} & "
                 f"{d['fnr'][0]:.4f} & {d['bal_accuracy'][0]:.4f} & "
                 f"{d['bal_f1'][0]:.4f} & {d['bal_fnr'][0]:.4f} \\\\")
    L += ["\\hline", "\\end{tabular}", "\\end{table}", ""]
    return "\n".join(L)


def t_permutation(rows):
    rs = [r for r in rows if r["exp"] == "E2"]
    if not rs:
        return ""
    r = rs[-1]
    items = sorted(r["rows"], key=lambda d: -d["drop"])[:12]
    inm = [d for d in r["rows"] if d["in_mask"]]
    out = [d for d in r["rows"] if not d["in_mask"]]
    mi = float(np.mean([d["drop"] for d in inm])) if inm else 0.0
    mo = float(np.mean([d["drop"] for d in out])) if out else 0.0
    from scipy.stats import spearmanr
    rho, pv = spearmanr([d["drop"] for d in r["rows"]],
                        [d["attribution"] for d in r["rows"]])
    L = [
        "\\begin{table}[htbp]", "\\centering",
        "\\caption{Feature-permutation ablation on the curated UNSW-NB15 "
        f"partition. Baseline accuracy {r['baseline']:.4f}. `Drop' is the loss "
        "in accuracy when that feature alone is randomly permuted in the test "
        "partition. The right-hand column records whether the consensus mask "
        "retained the feature.}",
        "\\label{tab:supp_permutation}",
        "\\begin{tabular}{lcc}", "\\hline",
        "Feature & Accuracy drop & Retained by mask \\\\", "\\hline",
    ]
    for d in items:
        fname = d["feature"].replace("_", r"\_")
        keep = "yes" if d["in_mask"] else "no"
        L.append(f"\\texttt{{{fname}}} & {d['drop']:.4f} & {keep} \\\\")
    L += ["\\hline",
          f"\\multicolumn{{3}}{{l}}{{Mean drop, features retained by the mask: "
          f"{mi:.4f} ($n={len(inm)}$)}} \\\\",
          f"\\multicolumn{{3}}{{l}}{{Mean drop, features discarded by the mask: "
          f"{mo:.4f} ($n={len(out)}$)}} \\\\",
          f"\\multicolumn{{3}}{{l}}{{Spearman $\\rho$ between permutation drop and "
          f"Jacobian attribution: {rho:.3f} ($p={pv:.2g}$)}} \\\\",
          "\\hline", "\\end{tabular}", "\\end{table}", ""]
    return "\n".join(L)


def t_evasion(rows):
    rs = [r for r in rows if r["exp"] == "E3"]
    if not rs:
        return ""
    a = agg(rs, lambda r: (r["defence"], r["attack"], r["eps"]))
    eps = sorted({k[2] for k in a})
    L = [
        "\\begin{table}[htbp]", "\\centering",
        "\\caption{Accuracy under standard gradient-based evasion attacks "
        "($\\ell_\\infty$ budget $\\epsilon$ on min--max normalised features), "
        "with and without the consensus mask applied at inference.}",
        "\\label{tab:supp_evasion}",
        "\\begin{tabular}{ll" + "c" * len(eps) + "}", "\\hline",
        "Attack & Mask & " + " & ".join(f"$\\epsilon={e:g}$" for e in eps)
        + " \\\\", "\\hline",
    ]
    for atk in ("fgsm", "pgd"):
        for tag, nm in (("mask", "applied"), ("nomask", "disabled")):
            cells = []
            for e in eps:
                k = (tag, atk, e)
                cells.append(f"{a[k]['accuracy'][0]:.4f}" if k in a else "--")
            L.append(f"{atk.upper()} & {nm} & " + " & ".join(cells) + " \\\\")
        L.append("\\hline")
    L += ["\\end{tabular}", "\\end{table}", ""]
    return "\n".join(L)


def t_falsified(rows):
    rs = [r for r in rows if r["exp"] == "E4"]
    if not rs:
        return ""
    a = agg(rs, lambda r: (r["defence"], r["mal_frac"]))
    mals = sorted({k[1] for k in a})
    L = [
        "\\begin{table}[htbp]", "\\centering",
        "\\caption{Falsified-validation attack. Compromised clients report a "
        "validation accuracy of 0.99 while submitting a corrupted update. "
        "`Defence on' uses drift-based trust weighting with a trimmed "
        "geometric median; `defence off' aggregates by the reported accuracy "
        "alone. `Weight captured' is the share of aggregation weight the "
        "compromised clients obtained.}",
        "\\label{tab:supp_falsified}",
        "\\begin{tabular}{lccc}", "\\hline",
        "Compromised clients & Defence & Accuracy & Weight captured \\\\",
        "\\hline",
    ]
    for m in mals:
        for tag, nm in (("on", "on"), ("off", "off")):
            k = (tag, m)
            if k not in a:
                continue
            d = a[k]
            mw = d.get("mal_weight", (0.0, 0.0))
            L.append(f"{int(m*100)}\\% & {nm} & {ms(d['accuracy'])} & "
                     f"{mw[0]:.3f} \\\\")
        L.append("\\hline")
    L += ["\\end{tabular}", "\\end{table}", ""]
    return "\n".join(L)


def t_feature_order(rows):
    """Reviewer 1 comment 3: does the semantic column ordering matter?"""
    nat = [r for r in rows if r["exp"] == "E1" and r.get("variant") == "fpn_only"]
    shuf = [r for r in rows if r["exp"] == "E6"]
    if not nat or not shuf:
        return ""
    a = agg(nat + shuf, lambda r: "shuffled" if r["exp"] == "E6" else "natural")
    n = min(a["natural"]["n"], a["shuffled"]["n"])
    L = [
        "\\begin{table}[htbp]", "\\centering",
        "\\caption{Feature-order ablation on the FPN-only variant. The column "
        "order is randomly permuted and the model retrained, so every feature "
        "is still present and only adjacency changes. The FPN-only "
        "configuration is used so the effect is not diluted by the two heads "
        f"that carry no locality assumption. Mean $\\pm$ s.d. over {n} folds.}}",
        "\\label{tab:supp_order}",
        "\\begin{tabular}{lccc}", "\\hline",
        "Feature order & Accuracy & F1 & FNR \\\\", "\\hline",
    ]
    for k, nm in (("natural", "Semantic grouping (as published)"),
                  ("shuffled", "Randomly permuted")):
        if k not in a:
            continue
        d = a[k]
        L.append(f"{nm} & {ms(d['accuracy'])} & {ms(d['f1'])} & "
                 f"{ms(d['fnr'])} \\\\")
    if "natural" in a and "shuffled" in a:
        d = a["natural"]["accuracy"][0] - a["shuffled"]["accuracy"][0]
        pooled = (a["natural"]["accuracy"][1] + a["shuffled"]["accuracy"][1]) / 2
        L += ["\\hline",
              f"\\multicolumn{{4}}{{l}}{{Difference in accuracy: {d:+.4f}, "
              f"against a pooled s.d. of {pooled:.4f}}} \\\\"]
    L += ["\\hline", "\\end{tabular}", "\\end{table}", ""]
    return "\n".join(L)


def t_agg_rules(rows):
    """MC^3-GRAM's aggregator against two published Byzantine-robust rules."""
    e4 = [r for r in rows if r["exp"] == "E4"]
    e7 = [r for r in rows if r["exp"] == "E7"]
    if not e7:
        return ""

    def rule_of(r):
        if r["exp"] == "E7":
            return r["rule"]
        return "mc3gram" if r["defence"] == "on" else "fedavg"

    a = agg(e4 + e7, lambda r: (rule_of(r), r["mal_frac"]))
    mals = sorted({k[1] for k in a})
    # Emit nothing until the grid is complete -- a table of dashes reads as a
    # missing result rather than as a run still in progress.
    wanted = {"mc3gram", "krum", "trimmed_mean", "fedavg"}
    if any((r, m) not in a for r in wanted for m in mals):
        return ""
    order = [("mc3gram", "MC$^3$-GRAM (trust + trimmed GM)"),
             ("krum", "Krum"),
             ("trimmed_mean", "Coordinate-wise trimmed mean"),
             ("fedavg", "Unweighted mean (no defence)")]
    L = [
        "\\begin{table}[htbp]", "\\centering",
        "\\caption{Accuracy under the falsified-validation attack for four "
        "aggregation rules. Compromised clients submit a corrupted update "
        "while reporting a validation accuracy of 0.99. Krum and the trimmed "
        "mean never read the reported score, so the attack cannot reach them "
        "through that channel; the comparison is therefore about what their "
        "robustness costs on an uncompromised federation.}",
        "\\label{tab:supp_aggrules}",
        "\\begin{tabular}{l" + "c" * len(mals) + "}", "\\hline",
        "& \\multicolumn{" + str(len(mals)) +
        "}{c}{Fraction of clients compromised} \\\\",
        "Aggregation rule & " +
        " & ".join(f"{int(m*100)}\\%" for m in mals) + " \\\\",
        "\\hline",
    ]
    for k, nm in order:
        cells = []
        for m in mals:
            key = (k, m)
            cells.append(f"{a[key]['accuracy'][0]:.4f}" if key in a else "--")
        L.append(f"{nm} & " + " & ".join(cells) + " \\\\")
    L += ["\\hline", "\\end{tabular}", "\\end{table}", ""]
    return "\n".join(L)


def t_cw(rows):
    rs = [r for r in rows if r["exp"] == "E8"]
    if not rs:
        return ""
    a = agg(rs, lambda r: (r["defence"], r["c"]))
    cs = sorted({k[1] for k in a})
    l2 = {k: float(np.mean([r["mean_l2"] for r in rs
                            if (r["defence"], r["c"]) == k])) for k in a}
    L = [
        "\\begin{table}[htbp]", "\\centering",
        "\\caption{Untargeted $L_2$ Carlini--Wagner attack, 60 optimisation "
        "steps, for three values of the margin weight $c$. `Mean $L_2$' is the "
        "average distance of the returned adversarial point from its original, "
        "on min--max normalised features; points the attack never flipped are "
        "returned unchanged. Clean accuracy on the same sample is 0.6557 with "
        "the mask applied and 0.6347 without.}",
        "\\label{tab:supp_cw}",
        "\\begin{tabular}{lccc}", "\\hline",
        "Mask & $c$ & Accuracy & Mean $L_2$ \\\\", "\\hline",
    ]
    for tag, nm in (("mask", "applied"), ("nomask", "disabled")):
        for c in cs:
            k = (tag, c)
            if k not in a:
                continue
            L.append(f"{nm} & {c:g} & {a[k]['accuracy'][0]:.4f} & "
                     f"{l2[k]:.4f} \\\\")
        L.append("\\hline")
    L += ["\\end{tabular}", "\\end{table}", ""]
    return "\n".join(L)


def t_wasserstein(rows):
    """The distribution of observed W1, and how often the hinge is exceeded."""
    rs = [r for r in rows if r["exp"] == "E9" and "w1_mean" in r]
    if not rs:
        return ""
    a = agg(rs, lambda r: r["xi"],
            fields=("w1_mean", "w1_sd", "w1_max", "w1_p95",
                    "w1_violation_rate"))
    nb = int(np.mean([r["w1_batches"] for r in rs]))
    n = max(v["n"] for v in a.values())
    L = [
        "\\begin{table}[htbp]", "\\centering",
        "\\caption{Critic-estimated 1-Wasserstein distance between the real and "
        "generated mini-batches, logged at every generator step under the soft "
        f"hinge of~\\eqref{{eq:wass}}. Mean over {n} folds, roughly {nb:,} batches "
        "each. `Violations' is the fraction of batches whose distance exceeded "
        "$\\xi$; because the hinge is a penalty rather than a constraint, that "
        "fraction is not zero.}",
        "\\label{tab:supp_wass}",
        "\\begin{tabular}{lccccc}", "\\hline",
        "$\\xi$ & Mean $W_1$ & s.d. & 95th pct. & Max $W_1$ & Violations \\\\",
        "\\hline",
    ]
    for xi in sorted(a):
        d = a[xi]
        L.append(f"{xi:g} & {d['w1_mean'][0]:.4f} & {d['w1_sd'][0]:.4f} & "
                 f"{d['w1_p95'][0]:.4f} & {d['w1_max'][0]:.4f} & "
                 f"{100 * d['w1_violation_rate'][0]:.1f}\\% \\\\")
    L += ["\\hline", "\\end{tabular}", "\\end{table}", ""]
    return "\n".join(L)


def t_imbalance(rows):
    rs = [r for r in rows if r["exp"] == "E5"]
    if not rs:
        return ""
    a = agg(rs, lambda r: r["alpha"])
    L = [
        "\\begin{table}[htbp]", "\\centering",
        "\\caption{Mask-consensus behaviour as the label skew varies. A smaller "
        "Dirichlet $\\alpha$ gives sharper skew, so clients hold fewer classes. "
        "Agreement is the mean pairwise Jaccard overlap between the three "
        "heads' feature votes.}",
        "\\label{tab:supp_imbalance}",
        "\\begin{tabular}{lcccc}", "\\hline",
        "Dirichlet $\\alpha$ & Head agreement & Accuracy & F1 & FNR \\\\",
        "\\hline",
    ]
    for al in sorted(a):
        d = a[al]
        L.append(f"{al:g} & {ms(d['agreement'], 3)} & {ms(d['accuracy'])} & "
                 f"{ms(d['f1'])} & {ms(d['fnr'])} \\\\")
    L += ["\\hline", "\\end{tabular}", "\\end{table}", ""]
    return "\n".join(L)


def main():
    rows = load()
    bad = check_identities(rows)
    print(f"loaded {len(rows)} result rows")
    if bad:
        print("IDENTITY VIOLATIONS -- nothing written:")
        for b in bad[:20]:
            print("  ", b)
        raise SystemExit(1)
    print("identity check: 0 violations")

    parts = [t_ablation(rows), t_balanced(rows), t_permutation(rows),
             t_feature_order(rows), t_evasion(rows), t_cw(rows),
             t_falsified(rows), t_agg_rules(rows), t_wasserstein(rows),
             t_imbalance(rows)]
    doc = "\n".join(p for p in parts if p)
    # These tables carry long configuration labels beside five columns of
    # "mean +- s.d." cells, which overruns the Springer text block at normal
    # size.  Applied here rather than in each generator so every table is
    # typeset identically.
    doc = doc.replace("\\centering",
                      "\\centering\n\\small\n\\setlength{\\tabcolsep}{4pt}")
    TEX.write_text(doc)
    print(f"wrote {TEX}")
    for name, p in zip(("ablation", "balanced", "permutation", "feature-order",
                        "evasion", "carlini-wagner", "falsified",
                        "agg-rules", "wasserstein", "imbalance"), parts):
        print(f"  {name}: {'ok' if p else 'no data yet'}")


if __name__ == "__main__":
    main()
