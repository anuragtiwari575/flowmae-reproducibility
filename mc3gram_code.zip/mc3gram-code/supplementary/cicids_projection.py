"""
Project the CICIDS-2017 binary rates onto the corpus's natural class balance.

Section 4.13 records that the CICIDS-2017 test partition was balanced before
the split, and calls re-deriving those rates on the natural distribution the
first item of remaining work.  That re-derivation does not need the corpus.

Recall and the false-positive rate are properties of the decision rule and do
not depend on prevalence.  Precision does.  So holding R and F at their
printed values and substituting the natural prevalence gives what the same
detector would have recorded on an unbalanced test partition:

    Prec(p) = R p / (R p + F (1-p))
    F1(p)   = 2 Prec(p) R / (Prec(p) + R)
    Acc(p)  = R p + (1-F)(1-p)

The same arithmetic that recovered the UNSW-NB15 test distribution is used
first to confirm that the CICIDS partition really is balanced, which is the
control: the method must return 0.5 on a corpus already declared to be at
equal support.
"""

from __future__ import annotations

# Table 4 of the manuscript
BENIGN = 2_273_097
ATTACK = 557_646
TOTAL = BENIGN + ATTACK
P_NAT = {"Benign": BENIGN / TOTAL, "Attack": ATTACK / TOTAL}

# Tables 13-15: class, accuracy, precision, recall, FPR, FNR (as percentages)
TABLES = {
    "10\\%": [
        ("Benign", 99.17, 99.30, 99.17, 0.64, 0.83),
        ("Attack", 99.35, 99.23, 99.35, 0.82, 0.65),
    ],
    "20\\%": [
        ("Benign", 98.27, 99.00, 98.27, 1.73, 1.73),
        ("Attack", 98.99, 98.27, 98.99, 1.01, 1.01),
    ],
}


def p_from_precision(prec, rec, fpr):
    num = prec * fpr
    den = rec * (1 - prec) + prec * fpr
    return num / den if den else None


def prec_at(rec, fpr, p):
    d = rec * p + fpr * (1 - p)
    return rec * p / d if d else 0.0


def f1_at(rec, fpr, p):
    pr = prec_at(rec, fpr, p)
    return 2 * pr * rec / (pr + rec) if (pr + rec) else 0.0


def acc_at(rec, fpr, p):
    return rec * p + (1 - fpr) * (1 - p)


def main():
    print(f"natural balance: Benign {P_NAT['Benign']:.4f}, "
          f"Attack {P_NAT['Attack']:.4f}  (Table 4)\n")

    for budget, rows in TABLES.items():
        print(f"=== perturbation budget {budget.replace(chr(92)+'%','%')} ===")
        print(f"{'class':<8}{'p implied':>11}{'p natural':>11} | "
              f"{'Prec now':>9}{'Prec nat':>9} | {'F1 now':>8}{'F1 nat':>8} | "
              f"{'Acc now':>8}{'Acc nat':>8}")
        for name, acc, prec, rec, fpr, _ in rows:
            a, pr, r, f = acc / 100, prec / 100, rec / 100, fpr / 100
            pi = p_from_precision(pr, r, f)
            pn = P_NAT[name]
            print(f"{name:<8}{pi:>11.4f}{pn:>11.4f} | "
                  f"{pr:>9.4f}{prec_at(r, f, pn):>9.4f} | "
                  f"{f1_at(r, f, pi):>8.4f}{f1_at(r, f, pn):>8.4f} | "
                  f"{a:>8.4f}{acc_at(r, f, pn):>8.4f}")
        print()

    print("The 'p implied' column is the control: it is recovered from the")
    print("printed precision and must come out at 0.5 for a partition that is")
    print("declared balanced.  Where it does, the natural-balance columns are")
    print("what the same detector would have recorded without the rebalancing.")


if __name__ == "__main__":
    main()
