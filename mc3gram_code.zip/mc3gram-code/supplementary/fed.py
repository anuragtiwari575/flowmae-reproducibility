"""
Federated layer, attack suites and evaluation.

    Eqs 36-38   client drift score, trust weights
    Eq  39      trimmed geometric median (Weiszfeld)
    Eqs 40-41   refinement, logit-space mask consensus

The metric block computes precision, recall and F1 directly from the confusion
matrix and then sets FNR = 1 - recall by definition, so the two consistency
identities the manuscript is checked against hold by construction rather than
by transcription.
"""

from __future__ import annotations

import copy
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import precision_recall_fscore_support, accuracy_score

from model import MC3GRAM, Generator, Critic, critic_clip, mask_consensus

import os

torch.set_num_threads(int(os.environ.get("MC3_THREADS", "2")))


# ------------------------------------------------------------------- metrics
def evaluate(model: nn.Module, X: np.ndarray, y: np.ndarray, bs: int = 4096) -> dict:
    model.eval()
    preds = []
    with torch.no_grad():
        for i in range(0, len(X), bs):
            xb = torch.from_numpy(X[i:i + bs])
            preds.append(model(xb).argmax(1).numpy())
    p = np.concatenate(preds)
    acc = accuracy_score(y, p)
    pr, rc, f1, _ = precision_recall_fscore_support(
        y, p, average="macro", zero_division=0)
    return {
        "accuracy": float(acc),
        "precision": float(pr),
        "recall": float(rc),
        "f1": float(f1),
        "fnr": float(1.0 - rc),          # identity, not a separate measurement
    }


# --------------------------------------------------------------- local training
def balanced_indices(y: np.ndarray, seed: int = 0) -> np.ndarray:
    """Indices of an equal-support subset, one class-count for every class.

    The manuscript's UNSW-NB15 per-class rates are computed one-vs-rest on a
    balanced test set.  Evaluating the same model on both this balanced subset
    and the natural distribution is what turns the balanced-test caveat in
    Section 4.13 from an acknowledgement into a measurement.
    """
    rng = np.random.default_rng(seed)
    classes, counts = np.unique(y, return_counts=True)
    n = int(counts.min())
    return np.concatenate([rng.choice(np.where(y == c)[0], n, replace=False)
                           for c in classes])


def local_train(model, X, y, epochs=1, lr=1e-3, bs=512, gen=None, mask=None,
                aug_frac=0.0, n_cls=10, max_batches=None):
    """One client's local update.  `gen` supplies generative augmentation."""
    model.train()
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    n = len(X)
    Xt, yt = torch.from_numpy(X), torch.from_numpy(y)
    for _ in range(epochs):
        perm = torch.randperm(n)
        nb = 0
        for i in range(0, n, bs):
            idx = perm[i:i + bs]
            xb, yb = Xt[idx], yt[idx]
            if xb.size(0) < 2:
                continue
            if gen is not None and aug_frac > 0:
                k = max(1, int(aug_frac * xb.size(0)))
                # augment the classes this client holds least of
                cnt = torch.bincount(yb, minlength=n_cls).float()
                cnt[cnt == 0] = float("inf")
                rare = torch.topk(-cnt, min(3, n_cls)).indices
                ys = rare[torch.randint(0, len(rare), (k,))]
                gen.eval()
                with torch.no_grad():
                    xs = gen(k, ys, mask if mask is not None
                             else torch.ones(X.shape[1]))
                xb = torch.cat([xb, xs], 0)
                yb = torch.cat([yb, ys], 0)
            opt.zero_grad()
            loss = F.cross_entropy(model(xb), yb)
            loss.backward()
            opt.step()
            nb += 1
            if max_batches and nb >= max_batches:
                break
    return model


def train_gan_local(gen, crt, X, y, mask, n_cls, steps=30, bs=256, lr=2e-4,
                    xi=None, gamma=0.5, w1_log=None):
    """A few steps of Wasserstein-hinge GAN training on one client (Eqs 28-33).

    `xi` activates the plausibility hinge of Eq. 33: the critic-estimated
    1-Wasserstein distance between the real and generated mini-batches,
    W1 = E[D(real)] - E[D(fake)], is penalised by gamma * max(0, W1 - xi).
    That is a soft term, so it pushes batches back toward the constraint
    without preventing violations -- which is exactly why `w1_log` records
    every per-batch W1, so the violation rate can be measured rather than
    assumed.
    """
    og = torch.optim.Adam(gen.parameters(), lr=lr, betas=(0.5, 0.9))
    oc = torch.optim.Adam(crt.parameters(), lr=lr, betas=(0.5, 0.9))
    Xt, yt = torch.from_numpy(X), torch.from_numpy(y)
    n = len(X)
    if n < bs:
        bs = max(8, n // 2)
    for s in range(steps):
        idx = torch.randint(0, n, (bs,))
        xr, yr = Xt[idx], yt[idx]
        # ---- critic
        gen.eval(); crt.train()
        with torch.no_grad():
            xf = gen(bs, yr, mask)
        wr, cr = crt(xr)
        wf, _ = crt(xf)
        # hinge form of the Wasserstein objective
        d_loss = (F.relu(1 - wr).mean() + F.relu(1 + wf).mean()
                  + F.cross_entropy(cr, yr))
        oc.zero_grad(); d_loss.backward(); oc.step()
        critic_clip(crt)                       # 1-Lipschitz, Eq. 32
        # ---- generator
        if s % 2 == 0:
            gen.train(); crt.eval()
            xf = gen(bs, yr, mask)
            wf, cf = crt(xf)
            g_loss = -wf.mean() + F.cross_entropy(cf, yr)
            if xi is not None:
                with torch.no_grad():
                    wr_g, _ = crt(xr)
                w1 = wr_g.mean() - wf.mean()           # critic estimate of W1
                g_loss = g_loss + gamma * torch.clamp(w1 - xi, min=0)
                if w1_log is not None:
                    w1_log.append(float(w1.detach()))
            og.zero_grad(); g_loss.backward(); og.step()
    return gen, crt


# ------------------------------------------------------- aggregation, Eqs 36-39
def flatten(sd):
    return torch.cat([v.flatten().float() for v in sd.values()])


def unflatten(vec, ref):
    out, i = {}, 0
    for k, v in ref.items():
        n = v.numel()
        out[k] = vec[i:i + n].view_as(v).to(v.dtype)
        i += n
    return out


def geometric_median(P, w, iters=12, eps=1e-8):
    """Weiszfeld iteration for the weighted geometric median (Eq. 39)."""
    m = (P * w[:, None]).sum(0) / w.sum()
    for _ in range(iters):
        d = torch.norm(P - m, dim=1).clamp_min(eps)
        ww = w / d
        m_new = (P * ww[:, None]).sum(0) / ww.sum()
        if torch.norm(m_new - m) < 1e-7:
            break
        m = m_new
    return m


def aggregate(global_sd, client_sds, reported_acc, trim=0.2,
              use_trust=True, use_gm=True, temp=1.0, rule="mc3gram",
              n_byzantine=0):
    """Trust-weighted, trimmed geometric-median aggregation.

    Trust combines *measured* drift with the client's *reported* validation
    accuracy.  That split is the point of the falsified-validation experiment:
    a client can inflate what it reports, but not the drift the server measures
    for itself.
    """
    g = flatten(global_sd)
    P = torch.stack([flatten(sd) for sd in client_sds])
    drift = torch.norm(P - g[None, :], dim=1)                    # Eq. 36

    # ---- published Byzantine-robust baselines, for comparison -------------
    # Neither consults the reported validation score at all, which is the
    # point of including them: they are robust without needing the quantity
    # the falsification attack targets.
    if rule == "krum":
        m = krum(P, n_byzantine)
        w_full = torch.zeros(len(P))
        sel = int(torch.argmin(torch.norm(P - m[None, :], dim=1)))
        w_full[sel] = 1.0
        return unflatten(m, global_sd), drift, w_full
    if rule == "trimmed_mean":
        m = trimmed_mean(P, trim_frac=trim if trim > 0 else 0.2)
        keep = max(1, len(P) - 2 * int(len(P) * (trim if trim > 0 else 0.2)))
        return (unflatten(m, global_sd), drift,
                torch.full((len(P),), 1.0 / len(P)))

    if use_trust:
        d = drift / (drift.median() + 1e-8)
        w = torch.softmax(-d / temp, 0) * torch.tensor(reported_acc)  # Eqs 37-38
        w = w.clamp_min(1e-8)
    else:
        w = torch.ones(len(P))
    w = w / w.sum()

    # `w_full` stays aligned to the original client order throughout, so the
    # caller can attribute weight back to specific clients.  Trimming zeroes a
    # client's entry rather than removing it from the vector -- dropping rows
    # here and indexing by the original position afterwards is precisely the
    # mistake that would make a trimmed-out attacker look heavily weighted.
    w_full = torch.zeros(len(P))
    if trim > 0 and len(P) >= 5:
        keep = int(round((1 - trim) * len(P)))
        order = torch.argsort(drift)[:keep]                       # trim by drift
        Pk, wk = P[order], w[order]
        wk = wk / wk.sum()
        w_full[order] = wk
    else:
        order = torch.arange(len(P))
        Pk, wk = P, w
        w_full = w.clone()

    m = geometric_median(Pk, wk) if use_gm else (Pk * wk[:, None]).sum(0)
    return unflatten(m, global_sd), drift, w_full


# ------------------------------------------------------------------- attacks
def krum(P, n_byzantine):
    """Krum (Blanchard et al.): pick the single update closest to its own
    nearest neighbours.

    Each candidate is scored by the sum of squared distances to its
    $n - f - 2$ nearest peers, and the lowest-scoring candidate is selected
    outright.  Selecting one update rather than combining them is what makes
    it robust, and also what makes it discard most of the honest signal.
    """
    n = len(P)
    k = max(1, n - n_byzantine - 2)
    D = torch.cdist(P, P) ** 2
    D.fill_diagonal_(float("inf"))
    scores = torch.topk(D, min(k, n - 1), dim=1, largest=False).values.sum(1)
    return P[int(torch.argmin(scores))]


def trimmed_mean(P, trim_frac=0.2):
    """Coordinate-wise trimmed mean: drop the extreme values of each
    coordinate independently, then average what is left."""
    n = len(P)
    k = int(n * trim_frac)
    if k == 0 or n - 2 * k < 1:
        return P.mean(0)
    S, _ = torch.sort(P, dim=0)
    return S[k:n - k].mean(0)


def carlini_wagner(model, X, y, steps=60, c=1.0, lr=0.01, kappa=0.0):
    """L2 Carlini-Wagner, untargeted.

    Optimises in tanh space so the iterate stays inside the valid [0, 1] box
    without projection, against the standard margin objective: push the true
    class logit below the best other logit by at least `kappa`, penalised by
    the squared L2 distance from the original point.
    """
    model.eval()
    x0 = torch.from_numpy(X).clamp(1e-6, 1 - 1e-6)
    yt = torch.from_numpy(y)
    w = torch.atanh(2 * x0 - 1).clone().requires_grad_(True)
    opt = torch.optim.Adam([w], lr=lr)
    best = x0.clone()
    best_l2 = torch.full((len(x0),), float("inf"))

    onehot = F.one_hot(yt, num_classes=model(x0[:1]).shape[1]).bool()
    for _ in range(steps):
        xa = (torch.tanh(w) + 1) / 2
        logits = model(xa)
        true_logit = logits[onehot]
        other = logits.masked_fill(onehot, -1e9).max(1).values
        margin = torch.clamp(true_logit - other + kappa, min=0)
        l2 = ((xa - x0) ** 2).sum(1)
        loss = (l2 + c * margin).sum()
        opt.zero_grad()
        loss.backward()
        opt.step()

        with torch.no_grad():
            xa = (torch.tanh(w) + 1) / 2
            adv = model(xa).argmax(1) != yt
            d = ((xa - x0) ** 2).sum(1)
            better = adv & (d < best_l2)
            best[better] = xa[better]
            best_l2[better] = d[better]

    # points never successfully perturbed are returned unchanged
    return best.detach().numpy()


def fgsm(model, X, y, eps):
    model.eval()
    xb = torch.from_numpy(X).clone().requires_grad_(True)
    loss = F.cross_entropy(model(xb), torch.from_numpy(y))
    g, = torch.autograd.grad(loss, xb)
    return torch.clamp(xb + eps * g.sign(), 0, 1).detach().numpy()


def pgd(model, X, y, eps, steps=7):
    model.eval()
    x0 = torch.from_numpy(X)
    xb = x0.clone()
    alpha = eps / 4
    yt = torch.from_numpy(y)
    for _ in range(steps):
        xb.requires_grad_(True)
        loss = F.cross_entropy(model(xb), yt)
        g, = torch.autograd.grad(loss, xb)
        xb = xb.detach() + alpha * g.sign()
        xb = torch.min(torch.max(xb, x0 - eps), x0 + eps).clamp(0, 1)
    return xb.detach().numpy()


# -------------------------------------------------------------- federated run
def run_federated(fold, cfg, log=print):
    """One federated training run.  `cfg` carries every ablation switch."""
    t0 = time.time()
    d_in = fold.X_val.shape[1]
    n_cls = len(fold.classes)
    heads = cfg.get("heads", ("fpn", "mlp", "trf"))
    torch.manual_seed(fold.seed)

    model = MC3GRAM(d_in, n_cls, heads=heads)
    gen = Generator(d_in, n_cls) if cfg.get("gan", True) else None
    crt = Critic(d_in, n_cls) if cfg.get("gan", True) else None

    cids = sorted(fold.clients)
    n_mal = int(round(cfg.get("mal_frac", 0.0) * len(cids)))
    malicious = set(cids[:n_mal])

    agreement = 1.0
    hist = []
    w1_log: list[float] = []
    for rnd in range(cfg.get("rounds", 8)):
        gsd = copy.deepcopy(model.state_dict())
        sds, accs = [], []
        for cid in cids:
            Xc, yc = fold.clients[cid]
            lm = MC3GRAM(d_in, n_cls, heads=heads)
            lm.load_state_dict(gsd)
            if cfg.get("gan", True) and cfg.get("gan_steps", 20) > 0:
                train_gan_local(gen, crt, Xc, yc, model.feature_mask, n_cls,
                                steps=cfg.get("gan_steps", 20),
                                xi=cfg.get("xi"), gamma=cfg.get("gamma", 0.5),
                                w1_log=w1_log if cfg.get("xi") is not None
                                else None)
            local_train(lm, Xc, yc, epochs=cfg.get("local_epochs", 1),
                        lr=cfg.get("lr", 1e-3), bs=cfg.get("bs", 512),
                        gen=gen, mask=model.feature_mask,
                        aug_frac=cfg.get("aug_frac", 0.15) if gen else 0.0,
                        n_cls=n_cls, max_batches=cfg.get("max_batches"))

            if cid in malicious:
                mode = cfg.get("attack", "falsified_validation")
                sd = lm.state_dict()
                if mode in ("falsified_validation", "model_poisoning"):
                    # send a damaging update ...
                    for k in sd:
                        if sd[k].dtype.is_floating_point:
                            sd[k] = sd[k] + torch.randn_like(sd[k]) * cfg.get(
                                "poison_scale", 1.0)
                    lm.load_state_dict(sd)
                # ... while reporting a perfect validation score
                rep = cfg.get("falsified_acc", 0.99)
            else:
                sub = np.random.default_rng(fold.seed + rnd).choice(
                    len(fold.X_val), size=min(4000, len(fold.X_val)), replace=False)
                rep = evaluate(lm, fold.X_val[sub], fold.y_val[sub])["accuracy"]

            sds.append(copy.deepcopy(lm.state_dict()))
            accs.append(rep)

        new_sd, drift, w = aggregate(
            gsd, sds, accs, trim=cfg.get("trim", 0.2),
            use_trust=cfg.get("trust", True), use_gm=cfg.get("gm", True),
            rule=cfg.get("rule", "mc3gram"), n_byzantine=n_mal)
        model.load_state_dict(new_sd)

        # ---- mask consensus from the refreshed global model (Eqs 26-27, 40-41)
        if cfg.get("mask", True):
            sub = np.random.default_rng(rnd).choice(
                len(fold.X_val), size=min(2000, len(fold.X_val)), replace=False)
            attr = model.attribution(torch.from_numpy(fold.X_val[sub]))
            m, agreement = mask_consensus(attr, cfg.get("keep_frac", 0.6),
                                          soft=cfg.get("soft_mask", False))
            model.feature_mask.copy_(m)

        hist.append({"round": rnd,
                     "val": evaluate(model, fold.X_val, fold.y_val)["accuracy"],
                     "agreement": agreement,
                     "mal_weight": float(sum(w[i] for i, c in enumerate(cids)
                                             if c in malicious)) if malicious else 0.0})

    res = evaluate(model, fold.X_test, fold.y_test)
    bidx = balanced_indices(fold.y_test, seed=fold.seed)
    bres = evaluate(model, fold.X_test[bidx], fold.y_test[bidx])
    res.update({f"bal_{k}": v for k, v in bres.items()})
    res.update(bal_n_per_class=int(len(bidx) // len(fold.classes)))
    if w1_log:
        arr = np.asarray(w1_log)
        xi = cfg.get("xi")
        res.update(w1_mean=float(arr.mean()), w1_sd=float(arr.std()),
                   w1_max=float(arr.max()), w1_p95=float(np.percentile(arr, 95)),
                   w1_violation_rate=float((arr > xi).mean()),
                   w1_batches=int(arr.size), xi=float(xi))
    res.update(fold=fold.fold, seed=fold.seed, agreement=agreement,
               secs=round(time.time() - t0, 1),
               mask_kept=int(model.feature_mask.sum().item()),
               n_features=d_in, n_clients=len(cids), history=hist)
    return model, res
