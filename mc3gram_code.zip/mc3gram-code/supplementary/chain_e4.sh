#!/bin/bash
cd /root/work/mc3gram_exp
# wait for the E4/E5 stream to exit before starting the corrected E4 re-run
while pgrep -f "exp E4 E5" > /dev/null; do sleep 20; done
MC3_THREADS=1 OMP_NUM_THREADS=1 exec python3 -u run.py --exp E4 >> out/run_e4b.log 2>&1
