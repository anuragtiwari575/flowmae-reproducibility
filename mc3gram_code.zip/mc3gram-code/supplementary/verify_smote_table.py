"""
Cross-verify the supplied SMOTE-ablation tables.

Two checks that do not require the run records:

  1. FNR = 1 - Recall.  On macro-averaged rates this holds by definition, so a
     table produced from a confusion matrix cannot fail it.  A failure means
     the columns were assembled from different sources.
  2. Agreement with the manuscript.  The "Full" rows should reproduce the
     Avg. rows of Tables 6-8 exactly, and the per-class recalls should match
     one of those three budgets.
"""

from __future__ import annotations

# ---- supplied table 1: macro rates -----------------------------------------
SUPPLIED = [
    # variant, budget, acc, macroF1, macroRecall, fpr, fnr
    ("Full",        "10%", 0.9894, 0.8807, 0.8795, 0.0059, 0.0991),
    ("w/o SMOTE",   "10%", 0.9738, 0.8246, 0.8179, 0.0087, 0.1158),
    ("Full",        "20%", 0.9815, 0.8647, 0.8612, 0.0103, 0.1141),
    ("w/o SMOTE",   "20%", 0.9617, 0.7895, 0.7774, 0.0148, 0.1383),
    ("Full",        "30%", 0.9793, 0.8588, 0.8541, 0.0115, 0.1310),
    ("w/o SMOTE",   "30%", 0.9489, 0.7548, 0.7386, 0.0189, 0.1597),
]

# ---- manuscript Avg. rows, Tables 6-8 --------------------------------------
PAPER_AVG = {                    # budget: acc, prec, rec, f1, fpr, fnr
    "10%": (0.9894, 0.8650, 0.9009, 0.8807, 0.0059, 0.0991),
    "20%": (0.9815, 0.8496, 0.8859, 0.8647, 0.0103, 0.1141),
    "30%": (0.9793, 0.8507, 0.8690, 0.8588, 0.0115, 0.1310),
}

# ---- supplied table 2: per-class recall (no budget stated) -----------------
SUPPLIED_PERCLASS = {"Worm": 0.87, "Shell Code": 0.60,
                     "Analysis": 0.84, "Backdoors": 0.82}

# ---- manuscript per-class recall, Tables 6-8 -------------------------------
PAPER_PERCLASS = {
    "10%": {"Worm": 0.7954, "Shell Code": 0.8354, "Analysis": 0.7392,
            "Backdoors": 0.9267},
    "20%": {"Worm": 0.7826, "Shell Code": 0.8675, "Analysis": 0.9182,
            "Backdoors": 0.8661},
    "30%": {"Worm": 0.6019, "Shell Code": 0.8705, "Analysis": 0.9355,
            "Backdoors": 0.8680},
}

# every class's recall at 10%, for reconstructing the macro average
PAPER_ALL_RECALL_10 = {
    "Normal": 0.9828, "Fuzzers": 0.9723, "Analysis": 0.7392,
    "Backdoors": 0.9267, "DoS": 0.9255, "Exploits": 0.9306,
    "Generic": 0.9692, "Reconnaissance": 0.9320, "Shell Code": 0.8354,
    "Worm": 0.7954,
}

TOL = 5e-4


def check_identity():
    print("CHECK 1  --  FNR = 1 - Macro Recall")
    print(f"  {'variant':<12}{'budget':>8}{'FNR':>9}{'1-Recall':>10}"
          f"{'gap':>9}   verdict")
    bad = 0
    for v, b, acc, f1, rec, fpr, fnr in SUPPLIED:
        implied = 1 - rec
        gap = abs(fnr - implied)
        ok = gap <= TOL
        bad += not ok
        print(f"  {v:<12}{b:>8}{fnr:>9.4f}{implied:>10.4f}{gap:>9.4f}"
              f"   {'ok' if ok else 'VIOLATION'}")
    print(f"  -> {bad} of {len(SUPPLIED)} rows fail an identity that holds by "
          f"construction\n")
    return bad


def check_against_paper():
    print("CHECK 2  --  do the 'Full' rows reproduce Tables 6-8?")
    for v, b, acc, f1, rec, fpr, fnr in SUPPLIED:
        if v != "Full":
            continue
        pacc, pprec, prec_, pf1, pfpr, pfnr = PAPER_AVG[b]
        print(f"  {b}: acc {acc}=={pacc} {'ok' if acc == pacc else 'DIFFERS'} | "
              f"F1 {f1}=={pf1} {'ok' if f1 == pf1 else 'DIFFERS'} | "
              f"FNR {fnr}=={pfnr} {'ok' if fnr == pfnr else 'DIFFERS'} | "
              f"Recall {rec} vs paper {prec_} "
              f"{'ok' if abs(rec - prec_) <= TOL else 'DIFFERS'}")
    print()


def check_perclass():
    print("CHECK 3  --  which budget do the per-class recalls belong to?")
    print(f"  {'class':<12}{'supplied':>10}" +
          "".join(f"{b:>10}" for b in PAPER_PERCLASS))
    for c, v in SUPPLIED_PERCLASS.items():
        row = "".join(f"{PAPER_PERCLASS[b][c]:>10.4f}" for b in PAPER_PERCLASS)
        print(f"  {c:<12}{v:>10.2f}{row}")
    print("\n  closest budget by mean absolute difference:")
    for b in PAPER_PERCLASS:
        d = sum(abs(SUPPLIED_PERCLASS[c] - PAPER_PERCLASS[b][c])
                for c in SUPPLIED_PERCLASS) / len(SUPPLIED_PERCLASS)
        print(f"    {b}: {d:.4f}")
    print()


def check_macro_consistency():
    print("CHECK 4  --  are table 2's numbers consistent with table 1's macro "
          "recall?")
    rec = dict(PAPER_ALL_RECALL_10)
    for c, v in SUPPLIED_PERCLASS.items():
        rec[c] = v
    macro = sum(rec.values()) / len(rec)
    claimed = 0.8795
    from_fnr = 1 - 0.0991
    print(f"  macro recall rebuilt from table 2 + the paper's other six "
          f"classes: {macro:.4f}")
    print(f"  table 1 claims:                                             "
          f"      {claimed:.4f}")
    print(f"  implied by table 1's own FNR (1 - 0.0991):                  "
          f"      {from_fnr:.4f}")
    print(f"  -> the three disagree; no single confusion matrix yields all "
          f"three\n")


def check_text_claims():
    print("CHECK 5  --  against explicit statements in the manuscript text")
    print("  Section 4.5: 'per-class recall stays at or above 0.739 at 10% "
          "perturbation'")
    print(f"    table 2 gives Shell Code = {SUPPLIED_PERCLASS['Shell Code']:.2f}"
          "  -> contradicts the text")
    print("  Section 4.5: 'at the 30% budget a deployment would miss roughly "
          "40% of Worm traffic'  (recall 0.602)")
    print(f"    table 2 gives Worm = {SUPPLIED_PERCLASS['Worm']:.2f}"
          "  -> contradicts the text at every budget\n")


if __name__ == "__main__":
    bad = check_identity()
    check_against_paper()
    check_perclass()
    check_macro_consistency()
    check_text_claims()
    print("=" * 62)
    print("A table computed from a confusion matrix satisfies check 1")
    print("automatically.  Six failures out of six means the Recall column")
    print("and the FNR column did not come from the same computation.")
