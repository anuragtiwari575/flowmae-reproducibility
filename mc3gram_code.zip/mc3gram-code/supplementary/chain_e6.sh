#!/bin/bash
cd /root/work/mc3gram_exp
while pgrep -f "exp E4$" > /dev/null || pgrep -f "run.py --exp E4" > /dev/null; do sleep 20; done
MC3_THREADS=2 OMP_NUM_THREADS=2 exec python3 -u run.py --exp E6 >> out/run_e6.log 2>&1
