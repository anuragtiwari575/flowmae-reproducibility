"""
Re-run the two consistency identities over every numeric row of the
manuscript, so that an edit cannot quietly reintroduce a defect.

    FNR = 1 - Recall
    F1  = 2 P R / (P + R)

Rows are recognised by shape: a label followed by six numbers in the order
Acc, Prec, Rec, F1, FPR, FNR.  Percent signs and LaTeX thousands separators
are handled; rows with '--' cells are skipped and counted separately.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

TOL = 5e-4

NUM = r"(-{2}|\d+\.\d+\\?%?|\d+\.\d+|\d+\\?%)"
ROW = re.compile(
    r"^\s*([A-Za-z][^&\\]*?)\s*&\s*" + r"\s*&\s*".join([NUM] * 6) + r"\s*\\\\")


def val(tok: str):
    """A trailing percent sign is authoritative; the magnitude heuristic is
    only a fallback for tables that print percentages without one."""
    if tok.strip() == "--":
        return None
    is_pct = "%" in tok
    t = tok.replace("\\%", "").replace("%", "").strip()
    try:
        v = float(t)
    except ValueError:
        return None
    if is_pct:
        return v / 100.0
    return v / 100.0 if v > 1.5 else v


def main(path: str):
    lines = Path(path).read_text().splitlines()
    checked = skipped = off_shape = 0
    bad = []
    # Only rows under a header in the order Acc, Prec, Rec, F1, FPR, FNR carry
    # the identities.  Other six-column tables exist (the balanced-vs-natural
    # comparison prints Acc, F1, FNR twice), and checking those as though they
    # were in the standard order produces false alarms.
    in_standard_table = False
    for n, line in enumerate(lines, 1):
        low = line.lower()
        if "&" in line and "\\\\" in line and ("prec" in low or "precision" in low):
            in_standard_table = ("rec" in low and "fnr" in low)
            continue
        if "\\end{tabular}" in line:
            in_standard_table = False
            continue
        m = ROW.match(line)
        if not m:
            continue
        if not in_standard_table:
            off_shape += 1
            continue
        label = m.group(1).strip()
        cells = [val(m.group(i)) for i in range(2, 8)]
        if any(c is None for c in cells):
            skipped += 1
            continue
        acc, prec, rec, f1, fpr, fnr = cells
        checked += 1
        if abs(fnr - (1 - rec)) > TOL:
            bad.append(f"L{n} {label}: FNR {fnr:.4f} vs 1-R {1-rec:.4f}")
        if prec + rec > 0:
            f1e = 2 * prec * rec / (prec + rec)
            if abs(f1 - f1e) > TOL:
                bad.append(f"L{n} {label}: F1 {f1:.4f} vs 2PR/(P+R) {f1e:.4f}")
    print(f"rows checked {checked}, rows with '--' skipped {skipped}, "
          f"rows in non-standard column orders skipped {off_shape}")
    if bad:
        print(f"VIOLATIONS: {len(bad)}")
        for b in bad:
            print("  ", b)
        return 1
    print("0 violations on both identities")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1
                          else "/root/work/paper/main.tex"))
